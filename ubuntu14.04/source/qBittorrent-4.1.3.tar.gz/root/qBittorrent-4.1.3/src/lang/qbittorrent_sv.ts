<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="sv">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../gui/aboutdialog.ui" line="15"/>
        <source>About qBittorrent</source>
        <translation>Om qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="52"/>
        <source>About</source>
        <translation>Om</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="81"/>
        <source>Author</source>
        <translation>Författare</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="87"/>
        <source>Current maintainer</source>
        <translation>Nuvarande underhållare</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="93"/>
        <source>Greece</source>
        <translation>Grekland</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="113"/>
        <location filename="../gui/aboutdialog.ui" line="204"/>
        <source>Nationality:</source>
        <translation>Nationalitet:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="120"/>
        <location filename="../gui/aboutdialog.ui" line="197"/>
        <source>E-mail:</source>
        <translation>E-post:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="127"/>
        <location filename="../gui/aboutdialog.ui" line="190"/>
        <source>Name:</source>
        <translation>Namn:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="157"/>
        <source>Original author</source>
        <translation>Ursprunglig författare</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="163"/>
        <source>France</source>
        <translation>Frankrike</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="241"/>
        <source>Special Thanks</source>
        <translation>Speciellt tack</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="267"/>
        <source>Translators</source>
        <translation>Översättare</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="293"/>
        <source>License</source>
        <translation>Licens</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="319"/>
        <source>Libraries</source>
        <translation>Bibliotek</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.ui" line="325"/>
        <source>qBittorrent was built with the following libraries:</source>
        <translation>qBittorrent byggdes med följande bibliotek:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.h" line="70"/>
        <source>An advanced BitTorrent client programmed in C++, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>En avancerad BitTorrent-klient programmerad i C++, baserad på Qt-verktygslåda och libtorrent-rasterbar.</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.h" line="71"/>
        <source>Copyright %1 2006-2018 The qBittorrent project</source>
        <translation>Copyright %1 2006-2018 The qBittorrent project</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.h" line="72"/>
        <source>Home Page:</source>
        <translation>Webbplats:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.h" line="73"/>
        <source>Forum:</source>
        <translation>Forum:</translation>
    </message>
    <message>
        <location filename="../gui/aboutdialog.h" line="74"/>
        <source>Bug Tracker:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="58"/>
        <source>Save at</source>
        <translation>Spara på</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="87"/>
        <source>Never show again</source>
        <translation>Visa aldrig igen</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="104"/>
        <source>Torrent settings</source>
        <translation>Torrentinställningar</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="110"/>
        <source>Set as default category</source>
        <translation>Sätt som standardkategori</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="119"/>
        <source>Category:</source>
        <translation>Kategori:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="144"/>
        <source>Start torrent</source>
        <translation>Starta torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="204"/>
        <source>Torrent information</source>
        <translation>Torrent information</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="154"/>
        <source>Skip hash check</source>
        <translation>Skippa hashkontroll</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="257"/>
        <source>Size:</source>
        <translation>Storlek:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="223"/>
        <source>Hash:</source>
        <translation>Hash:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="271"/>
        <source>Comment:</source>
        <translation>Kommentar:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="250"/>
        <source>Date:</source>
        <translation>Datum:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="19"/>
        <source>Torrent Management Mode:</source>
        <translation>Torrenthanteringsläge:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="26"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>Automatiskt läge betyder att vissa torrentegenskaper (t.ex. var filen ska sparas) bestäms av filens kategori</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="30"/>
        <source>Manual</source>
        <translation>Manuellt</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="35"/>
        <source>Automatic</source>
        <translation>Automatiskt</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="67"/>
        <source>Remember last used save path</source>
        <translation>Kom ihåg den senast använda spara sökvägen</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="77"/>
        <source>When checked, the .torrent file will not be deleted despite the settings at the &quot;Download&quot; page of the options dialog</source>
        <translation>Om kryssad, kommer .torrent-filen inte tas bort trots inställningarna på &quot;Hämta&quot;-sidan i dialogrutan Alternativ</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="80"/>
        <source>Do not delete .torrent file</source>
        <translation>Radera inte .torrent-fil</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="177"/>
        <source>Create subfolder</source>
        <translation>Skapa undermapp</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="187"/>
        <source>Download in sequential order</source>
        <translation>Hämta i sekventiell ordning</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="194"/>
        <source>Download first and last pieces first</source>
        <translation>Hämta första och sista bitarna först</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="376"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="381"/>
        <source>High</source>
        <translation>Hög</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="386"/>
        <source>Maximum</source>
        <translation>Högsta</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="391"/>
        <source>Do not download</source>
        <translation>Hämta inte</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="275"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="281"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="706"/>
        <source>I/O Error</source>
        <translation>In-/Ut-fel</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="289"/>
        <source>Invalid torrent</source>
        <translation>Ogiltig torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="493"/>
        <source>Renaming</source>
        <translation>Byter namn</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="498"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="522"/>
        <source>Rename error</source>
        <translation>Fel vid namnbyte</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="499"/>
        <source>The name is empty or contains forbidden characters, please choose a different one.</source>
        <translation>Namnet är tomt eller innehåller förbjudna tecken, vänligen välj ett annat filnamn.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="732"/>
        <source>Not Available</source>
        <comment>This comment is unavailable</comment>
        <translation>Inte tillgänglig</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="733"/>
        <source>Not Available</source>
        <comment>This date is unavailable</comment>
        <translation>Inte tillgänglig</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="741"/>
        <source>Not available</source>
        <translation>Inte tillgänglig</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="325"/>
        <source>Invalid magnet link</source>
        <translation>Ogiltig magnetlänk</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="275"/>
        <source>The torrent file &apos;%1&apos; does not exist.</source>
        <translation>Torrentfilen &apos;%1&apos; finns inte.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="281"/>
        <source>The torrent file &apos;%1&apos; cannot be read from the disk. Probably you don&apos;t have enough permissions.</source>
        <translation>Torrentfilen &apos;%1&apos; kan inte läsas från disken. Du har förmodligen inte diskbehörigheterna som krävs.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="289"/>
        <source>Failed to load the torrent: %1.
Error: %2</source>
        <comment>Don&apos;t remove the &apos;
&apos; characters. They insert a newline.</comment>
        <translation>Kunde inte ladda torrenten: %1
Fel: %2</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="325"/>
        <source>This magnet link was not recognized</source>
        <translation>Denna magnetlänk känns ej igen</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="354"/>
        <source>Magnet link</source>
        <translation>Magnetlänk</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="360"/>
        <source>Retrieving metadata...</source>
        <translation>Hämtar metadata...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="444"/>
        <source>Not Available</source>
        <comment>This size is unavailable.</comment>
        <translation>Inte tillgänglig</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="446"/>
        <source>Free space on disk: %1</source>
        <translation>Ledigt diskutrymme: %1</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="101"/>
        <source>Choose save path</source>
        <translation>Välj sökväg att spara i</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="302"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="307"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="311"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="336"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="341"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="345"/>
        <source>Torrent is already present</source>
        <translation>Torrent är redan närvarande</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="302"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="336"/>
        <source>Torrent &apos;%1&apos; is already in the transfer list. Trackers haven&apos;t been merged because it is a private torrent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="307"/>
        <source>Torrent &apos;%1&apos; is already in the transfer list. Trackers have been merged.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="311"/>
        <source>Torrent is already queued for processing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="341"/>
        <source>Magnet link &apos;%1&apos; is already in the transfer list. Trackers have been merged.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="345"/>
        <source>Magnet link is already queued for processing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="493"/>
        <source>New name:</source>
        <translation>Nytt namn:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="523"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="561"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Detta namn används redan i denna mapp. Använd ett annat namn.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="560"/>
        <source>The folder could not be renamed</source>
        <translation>Det gick inte att byta namn på mappen</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="608"/>
        <source>Rename...</source>
        <translation>Byt namn...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="612"/>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="707"/>
        <source>Invalid metadata</source>
        <translation>Ogiltig metadata</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="714"/>
        <source>Parsing metadata...</source>
        <translation>Löser metadata...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="718"/>
        <source>Metadata retrieval complete</source>
        <translation>Hämtning av metadata klart</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="773"/>
        <source>Download Error</source>
        <translation>Hämtningsfel</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="252"/>
        <source> MiB</source>
        <translation> MiB</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="385"/>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Utgående portar (Min) [0: Inaktiverat]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="390"/>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Utgående portar (Max) [0: Inaktiverat]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="400"/>
        <source>Recheck torrents on completion</source>
        <translation>Kontrollera torrenter igen vid färdigställande</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="406"/>
        <source>Transfer list refresh interval</source>
        <translation>Uppdateringsintervall för överföringslista</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="405"/>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="123"/>
        <source>Setting</source>
        <translation>Inställning</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="123"/>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Värde</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="248"/>
        <location filename="../gui/advancedsettings.cpp" line="260"/>
        <source> (disabled)</source>
        <translation>(inaktiverad)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="250"/>
        <source> (auto)</source>
        <translation>(auto)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="258"/>
        <source> min</source>
        <comment> minutes</comment>
        <translation> min</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="271"/>
        <source>All addresses</source>
        <translation>Alla adresser</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="308"/>
        <source>qBittorrent Section</source>
        <translation>qBittorrent-sektion</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="311"/>
        <location filename="../gui/advancedsettings.cpp" line="316"/>
        <source>Open documentation</source>
        <translation>Öppna dokumentationen</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="314"/>
        <source>libtorrent Section</source>
        <translation>libtorrent-sektion</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="324"/>
        <source>Asynchronous I/O threads</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="338"/>
        <source>Disk cache</source>
        <translation>Diskcache</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="343"/>
        <source> s</source>
        <comment> seconds</comment>
        <translation> s</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="344"/>
        <source>Disk cache expiry interval</source>
        <translation>Interval för utgång av diskcache</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="347"/>
        <source>Enable OS cache</source>
        <translation>Slå på OS-cache</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="350"/>
        <source>Guided read cache</source>
        <translation>Guidad läscache</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="354"/>
        <source>Coalesce reads &amp; writes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="358"/>
        <source>Send upload piece suggestions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="362"/>
        <location filename="../gui/advancedsettings.cpp" line="367"/>
        <source> KiB</source>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="364"/>
        <source>Send buffer watermark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="369"/>
        <source>Send buffer low watermark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="374"/>
        <source>Send buffer watermark factor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="392"/>
        <source>Prefer TCP</source>
        <translation>Föredra TCP</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="392"/>
        <source>Peer proportional (throttles TCP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="397"/>
        <source>Allow multiple connections from the same IP address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="409"/>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Slå upp klienternas länder (GeoIP)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="412"/>
        <source>Resolve peer host names</source>
        <translation>Slå upp klienternas värdnamn</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="420"/>
        <source>Strict super seeding</source>
        <translation>Strikt superdistribuering</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="445"/>
        <source>Network Interface (requires restart)</source>
        <translation>Nätverksgränssnitt (kräver omstart)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="448"/>
        <source>Optional IP Address to bind to (requires restart)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="451"/>
        <source>Listen on IPv6 address (requires restart)</source>
        <translation>Lyssna på IPv6-adresser (kräver omstart)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="459"/>
        <source>Display notifications</source>
        <translation>Visa aviseringar</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="462"/>
        <source>Display notifications for added torrents</source>
        <translation>Visa aviseringar för tillagda torrenter</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="465"/>
        <source>Download tracker&apos;s favicon</source>
        <translation>Hämta spårarens favicon</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="469"/>
        <source>Save path history length</source>
        <translation>Spara längd för sökvägshistorik</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="479"/>
        <source>Fixed slots</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="479"/>
        <source>Upload rate based</source>
        <translation>Sändning betygbaserad</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="481"/>
        <source>Upload slots behavior</source>
        <translation>Beteende för sändningsplatser</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="483"/>
        <source>Round-robin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="483"/>
        <source>Fastest upload</source>
        <translation>Snabbaste sändning</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="483"/>
        <source>Anti-leech</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="485"/>
        <source>Upload choking algorithm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="497"/>
        <source>Confirm torrent recheck</source>
        <translation>Bekräfta återkoll av torrent</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="501"/>
        <source>Confirm removal of all tags</source>
        <translation>Bekräfta borttagning av alla taggar</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="505"/>
        <source>Always announce to all trackers in a tier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="509"/>
        <source>Always announce to all tiers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="422"/>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Valfritt gränssnitt</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="380"/>
        <source>Save resume data interval</source>
        <comment>How often the fastresume file is saved.</comment>
        <translation>Interval för sparning av återupptagningsdata</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="394"/>
        <source>%1-TCP mixed mode algorithm</source>
        <comment>uTP-TCP mixed mode algorithm</comment>
        <translation>%1-TCP blandad lägesalgoritm</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="417"/>
        <source>Maximum number of half-open connections [0: Unlimited]</source>
        <translation>Högsta antal halvöppna anslutningar [0: inaktiverat]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="454"/>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>IP-adress att rapportera till bevakare (kräver omstart)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="472"/>
        <source>Enable embedded tracker</source>
        <translation>Aktivera inbäddad bevakare</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="477"/>
        <source>Embedded tracker port</source>
        <translation>Port för inbäddad bevakare</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="489"/>
        <source>Check for software updates</source>
        <translation>Leta efter programuppdateringar</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="493"/>
        <source>Use system icon theme</source>
        <translation>Använd systemets ikontema</translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <location filename="../app/application.cpp" line="157"/>
        <source>qBittorrent %1 started</source>
        <comment>qBittorrent v3.2.0alpha started</comment>
        <translation>qBittorrent %1 startad</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="308"/>
        <source>Torrent: %1, running external program, command: %2</source>
        <translation>Torrent: %1, kör externt program, kommando: %2</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="335"/>
        <source>Torrent name: %1</source>
        <translation>Torrentnamn: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="336"/>
        <source>Torrent size: %1</source>
        <translation>Torrentstorlek: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="337"/>
        <source>Save path: %1</source>
        <translation>Spara sökvägen: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="338"/>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation>Torrent hämtades i %1.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="340"/>
        <source>Thank you for using qBittorrent.</source>
        <translation>Tack för att ni använde qBittorrent.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="347"/>
        <source>[qBittorrent] &apos;%1&apos; has finished downloading</source>
        <translation>[qBittorrent] &apos;%1&apos; har slutförd hämtningen</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="361"/>
        <source>Torrent: %1, sending mail notification</source>
        <translation>Torrent: %1, skickar e-postavisering</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="522"/>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="523"/>
        <source>To control qBittorrent, access the Web UI at %1</source>
        <translation>För att styra qBittorrent, öppna webbgränssnittet på %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="525"/>
        <source>The Web UI administrator user name is: %1</source>
        <translation>Administratörsnamnet för webbgränssnittet är: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="529"/>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>Lösenordet för administratören på webbgränssnittet är standardlösenordet: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="530"/>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Detta är en säkerhetsrisk så överväg att ändra ditt lösenord från programinställningarna.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="693"/>
        <source>Saving torrent progress...</source>
        <translation>Sparar torrents framsteg...</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="750"/>
        <source>Portable mode and explicit profile directory options are mutually exclusive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="753"/>
        <source>Portable mode implies relative fastresume</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AuthController</name>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="54"/>
        <source>WebAPI login failure. Reason: IP has been banned, IP: %1, username: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="58"/>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="76"/>
        <source>WebAPI login success. IP: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/authcontroller.cpp" line="81"/>
        <source>WebAPI login failure. Reason: invalid credentials, attempt count: %1, IP: %2, username: %3</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="240"/>
        <source>Save to:</source>
        <translation>Spara till:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="14"/>
        <source>RSS Downloader</source>
        <translation>RSS Hämtare</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="28"/>
        <source>Auto downloading of RSS torrents is disabled now! You can enable it in application settings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="59"/>
        <source>Download Rules</source>
        <translation>Hämtningsregler</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="99"/>
        <source>Rule Definition</source>
        <translation>Regeldefinition</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="105"/>
        <source>Use Regular Expressions</source>
        <translation>Använd reguljära uttryck</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="186"/>
        <source>Smart Episode Filter will check the episode number to prevent downloading of duplicates.
Supports the formats: S01E01, 1x1, 2017.01.01 and 01.01.2017 (Date formats also support - as a separator)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="190"/>
        <source>Use Smart Episode Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="114"/>
        <source>Must Contain:</source>
        <translation>Måste innehålla:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="121"/>
        <source>Must Not Contain:</source>
        <translation>Får inte innehålla:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="128"/>
        <source>Episode Filter:</source>
        <translation>Avsnittsfilter:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="212"/>
        <source>Assign Category:</source>
        <translation>Tilldela kategori:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="228"/>
        <source>Save to a Different Directory</source>
        <translation>Spara till en annan katalog</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="268"/>
        <source>Ignore Subsequent Matches for (0 to Disable)</source>
        <comment>... X days</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="278"/>
        <source>Disabled</source>
        <translation>Inaktiverad</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="281"/>
        <source> days</source>
        <translation>dagar</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="314"/>
        <source>Add Paused:</source>
        <translation>Lägg till pausad:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="322"/>
        <source>Use global settings</source>
        <translation>Använd allmän inställning</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="327"/>
        <source>Always</source>
        <translation>Alltid</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="332"/>
        <source>Never</source>
        <translation>Aldrig</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="353"/>
        <source>Apply Rule to Feeds:</source>
        <translation>Tillämpa regel till flöden:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="375"/>
        <source>Matching RSS Articles</source>
        <translation>Matcha RSS-artiklar</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="403"/>
        <source>&amp;Import...</source>
        <translation>Importera...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="413"/>
        <source>&amp;Export...</source>
        <translation>Exportera...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="86"/>
        <source>Matches articles based on episode filter.</source>
        <translation>Matchar artiklar baserat på avsnittsfilter.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="86"/>
        <source>Example: </source>
        <translation>Exempel:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="87"/>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <comment>example X will match</comment>
        <translation>kommer matcha 2, 5, 8 genom 15, 30 och framåt på avsnittet säsong ett</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="88"/>
        <source>Episode filter rules: </source>
        <translation>Regler för avsnittsfilter:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="88"/>
        <source>Season number is a mandatory non-zero value</source>
        <translation>Säsongsnummer är ett krav för värden över noll</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="90"/>
        <source>Filter must end with semicolon</source>
        <translation>Filter måste sluta med semikolon</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="91"/>
        <source>Three range types for episodes are supported: </source>
        <translation>Tre olika typer av episoder stöds:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="92"/>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation>Ensamma siffror: &lt;b&gt;1x25;&lt;/b&gt; matchar episod 25 av säsong ett</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="93"/>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation>Vanligt intervall: &lt;b&gt;1x25-40;&lt;/b&gt;matchar episoderna 25 till 40 av säsong ett</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="89"/>
        <source>Episode number is a mandatory positive value</source>
        <translation>Episodnummer är ett obligatoriskt positivt värde</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="62"/>
        <source>Rules</source>
        <translation>Regler</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="63"/>
        <source>Rules (legacy)</source>
        <translation>Regler (legacy)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="94"/>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one, and all episodes of later seasons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="276"/>
        <source>Last Match: %1 days ago</source>
        <translation>Senaste matchning: %1 dagar sedan</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="278"/>
        <source>Last Match: Unknown</source>
        <translation>Senaste matchning: Okänd</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="361"/>
        <source>New rule name</source>
        <translation>Namn för ny regel</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="361"/>
        <source>Please type the name of the new download rule.</source>
        <translation>Ange det nya regelnamnet.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="366"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="518"/>
        <source>Rule name conflict</source>
        <translation>Namnkonflikt för regler</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="367"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="519"/>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>En regel med denna namn finns redan. Välj ett annat namn.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="381"/>
        <source>Are you sure you want to remove the download rule named &apos;%1&apos;?</source>
        <translation>Är du säker på att du vill ta bort hämtningsregeln %1?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="383"/>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Är du säker på att du vill ta bort de markerade hämtningsreglerna?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="384"/>
        <source>Rule deletion confirmation</source>
        <translation>Bekräfta regelborttagning</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="393"/>
        <source>Destination directory</source>
        <translation>Målkatalog</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="401"/>
        <source>Invalid action</source>
        <translation>Ogiltig åtgärd</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="402"/>
        <source>The list is empty, there is nothing to export.</source>
        <translation>Listan är tom, det finns inget att exportera.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="408"/>
        <source>Export RSS rules</source>
        <translation>Exportera RSS-regler</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="431"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="448"/>
        <source>I/O Error</source>
        <translation>I/O Fel</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="432"/>
        <source>Failed to create the destination file. Reason: %1</source>
        <translation>Misslyckades med att skapa destinationsfilen. Anledning: %1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="440"/>
        <source>Import RSS rules</source>
        <translation>Importera RSS-regler</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="449"/>
        <source>Failed to open the file. Reason: %1</source>
        <translation>Misslyckades med att öppna filen. Anledning: %1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="464"/>
        <source>Import Error</source>
        <translation>Fel vid Importering</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="465"/>
        <source>Failed to import the selected rules file. Reason: %1</source>
        <translation>Misslyckades med att importera den valda regelfilen. Anledning: %1</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="472"/>
        <source>Add new rule...</source>
        <translation>Lägg till ny regel...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="480"/>
        <source>Delete rule</source>
        <translation>Ta bort regel</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="482"/>
        <source>Rename rule...</source>
        <translation>Byt namn på regel...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="485"/>
        <source>Delete selected rules</source>
        <translation>Ta bort markerade regler</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="488"/>
        <source>Clear downloaded episodes...</source>
        <translation>Rensa hämtade episoder...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="512"/>
        <source>Rule renaming</source>
        <translation>Byt namn på regel</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="512"/>
        <source>Please type the new rule name</source>
        <translation>Ange det nya regelnamnet</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="538"/>
        <source>Clear downloaded episodes</source>
        <translation>Rensa hämtade episoder</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="539"/>
        <source>Are you sure you want to clear the list of downloaded episodes for the selected rule?</source>
        <translation>Är du säker på att du vill rensa listan över hämtade episoder för den valda regeln?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="643"/>
        <source>Regex mode: use Perl-compatible regular expressions</source>
        <translation>Regex-läge: använd Perl-kompatibla reguljära uttryck</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="685"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="723"/>
        <source>Position %1: %2</source>
        <translation>Position %1: %2</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="646"/>
        <source>Wildcard mode: you can use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="647"/>
        <source>? to match any single character</source>
        <translation>? för att matcha alla enskilda tecken</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="648"/>
        <source>* to match zero or more of any characters</source>
        <translation>* för att matcha noll eller fler av några tecken</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="649"/>
        <source>Whitespaces count as AND operators (all words, any order)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="650"/>
        <source>| is used as OR operator</source>
        <translation>| används som OR-operatör</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="651"/>
        <source>If word order is important use * instead of whitespace.</source>
        <translation>Om ordföljden är viktig, användning * i stället för blanksteg.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="658"/>
        <source>An expression with an empty %1 clause (e.g. %2)</source>
        <comment>We talk about regex/wildcards in the RSS filters section here. So a valid sentence would be: An expression with an empty | clause (e.g. expr|)</comment>
        <translation>Ett uttryck med en tom %1-klausul (t.ex. %2)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="662"/>
        <source> will match all articles.</source>
        <translation>kommer att matcha alla artiklar.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="663"/>
        <source> will exclude all articles.</source>
        <translation>kommer exkludera alla artiklar.</translation>
    </message>
</context>
<context>
    <name>BanListOptionsDialog</name>
    <message>
        <location filename="../gui/banlistoptionsdialog.ui" line="14"/>
        <source>List of banned IP addresses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.ui" line="77"/>
        <source>Ban IP</source>
        <translation>Bannlys IP</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.ui" line="84"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.cpp" line="87"/>
        <location filename="../gui/banlistoptionsdialog.cpp" line="97"/>
        <source>Warning</source>
        <translation>Varning</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.cpp" line="87"/>
        <source>The entered IP address is invalid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/banlistoptionsdialog.cpp" line="97"/>
        <source>The entered IP is already banned.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BitTorrent::Session</name>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="596"/>
        <source>Restart is required to toggle PeX support</source>
        <translation>Omstart krävs för att växla PeX-stöd</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1245"/>
        <source>Could not get GUID of configured network interface. Binding to IP %1</source>
        <translation>Det gick inte att få GUID för konfigurerat nätverksgränssnitt. Bindning till IP %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1744"/>
        <source>Embedded Tracker [ON]</source>
        <translation>Inbäddad bevakare [PÅ]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1746"/>
        <source>Failed to start the embedded tracker!</source>
        <translation>Misslyckades med att starta den inbäddade bevakaren!</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1749"/>
        <source>Embedded Tracker [OFF]</source>
        <translation>Inbäddad bevakare [AV]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2427"/>
        <source>System network status changed to %1</source>
        <comment>e.g: System network status changed to ONLINE</comment>
        <translation>Systemnätverksstatus ändrad till %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2427"/>
        <source>ONLINE</source>
        <translation>ONLINE</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2427"/>
        <source>OFFLINE</source>
        <translation>OFFLINE</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2449"/>
        <source>Network configuration of %1 has changed, refreshing session binding</source>
        <comment>e.g: Network configuration of tun0 has changed, refreshing session binding</comment>
        <translation>Nätverkskonfigurationen för %1 har ändrats, uppdaterar sessionsbindning</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2466"/>
        <source>Configured network interface address %1 isn&apos;t valid.</source>
        <comment>Configured network interface address 124.5.1568.1 isn&apos;t valid.</comment>
        <translation>Konfigurerad nätverksgränssnittsadress %1 är inte giltig.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="482"/>
        <location filename="../base/bittorrent/session.cpp" line="2813"/>
        <source>Encryption support [%1]</source>
        <translation>Krypteringsstöd [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="483"/>
        <location filename="../base/bittorrent/session.cpp" line="2814"/>
        <source>FORCED</source>
        <translation>Tvingad</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2938"/>
        <source>%1 is not a valid IP address and was rejected while applying the list of banned addresses.</source>
        <translation>%1 är inte en giltig IP-adress och kunde inte läggas till i listan av förbjudna adresser.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="481"/>
        <location filename="../base/bittorrent/session.cpp" line="3189"/>
        <source>Anonymous mode [%1]</source>
        <translation>Anonymitetsläge [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3691"/>
        <source>Unable to decode &apos;%1&apos; torrent file.</source>
        <translation>Det gick inte att avkoda &quot;%1&quot; torrentfilen.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3828"/>
        <source>Recursive download of file &apos;%1&apos; embedded in torrent &apos;%2&apos;</source>
        <comment>Recursive download of &apos;test.torrent&apos; embedded in torrent &apos;test2&apos;</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3928"/>
        <source>Queue positions were corrected in %1 resume files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4149"/>
        <source>Couldn&apos;t save &apos;%1.torrent&apos;</source>
        <translation>Kunde inte spara &apos;%1.torrent&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4196"/>
        <source>&apos;%1&apos; was removed from the transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&quot;%1&quot; har tagits bort från överföringslistan.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4209"/>
        <source>&apos;%1&apos; was removed from the transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&quot;%1&quot; har tagits bort från överföringslistan och hårddisken.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4221"/>
        <source>&apos;%1&apos; was removed from the transfer list but the files couldn&apos;t be deleted. Error: %2</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&quot;%1&quot; har tagits bort från överföringslistan men filerna kunde inte raderas. Fel: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4286"/>
        <source>because %1 is disabled.</source>
        <comment>this peer was blocked because uTP is disabled.</comment>
        <translation>pga att %1 är inaktiverat.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4289"/>
        <source>because %1 is disabled.</source>
        <comment>this peer was blocked because TCP is disabled.</comment>
        <translation>pga att %1 är inaktiverat.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4307"/>
        <source>URL seed lookup failed for URL: &apos;%1&apos;, message: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4355"/>
        <source>qBittorrent failed listening on interface %1 port: %2/%3. Reason: %4.</source>
        <comment>e.g: qBittorrent failed listening on interface 192.168.0.1 port: TCP/6881. Reason: already in use.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2090"/>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Hämtar &quot;%1&quot;, vänligen vänta...</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1209"/>
        <location filename="../base/bittorrent/session.cpp" line="2543"/>
        <source>qBittorrent is trying to listen on any interface port: %1</source>
        <comment>e.g: qBittorrent is trying to listen on any interface port: TCP/6881</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2485"/>
        <source>The network interface defined is invalid: %1</source>
        <translation>Nätverksgränssnittet som definierats är ogiltig: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1222"/>
        <location filename="../base/bittorrent/session.cpp" line="2554"/>
        <source>qBittorrent is trying to listen on interface %1 port: %2</source>
        <comment>e.g: qBittorrent is trying to listen on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>qBittorrent försöker lyssna på gränssnittet %1 port: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="476"/>
        <source>Peer ID: </source>
        <translation>Nod-ID: </translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="477"/>
        <source>HTTP User-Agent is &apos;%1&apos;</source>
        <translation>HTTP-användaragent är &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="478"/>
        <location filename="../base/bittorrent/session.cpp" line="567"/>
        <source>DHT support [%1]</source>
        <translation>DHT-stöd [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="478"/>
        <location filename="../base/bittorrent/session.cpp" line="479"/>
        <location filename="../base/bittorrent/session.cpp" line="480"/>
        <location filename="../base/bittorrent/session.cpp" line="481"/>
        <location filename="../base/bittorrent/session.cpp" line="483"/>
        <location filename="../base/bittorrent/session.cpp" line="567"/>
        <location filename="../base/bittorrent/session.cpp" line="582"/>
        <location filename="../base/bittorrent/session.cpp" line="2814"/>
        <location filename="../base/bittorrent/session.cpp" line="3189"/>
        <source>ON</source>
        <translation>PÅ</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="478"/>
        <location filename="../base/bittorrent/session.cpp" line="479"/>
        <location filename="../base/bittorrent/session.cpp" line="480"/>
        <location filename="../base/bittorrent/session.cpp" line="481"/>
        <location filename="../base/bittorrent/session.cpp" line="483"/>
        <location filename="../base/bittorrent/session.cpp" line="567"/>
        <location filename="../base/bittorrent/session.cpp" line="582"/>
        <location filename="../base/bittorrent/session.cpp" line="2814"/>
        <location filename="../base/bittorrent/session.cpp" line="3189"/>
        <source>OFF</source>
        <translation>AV</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="479"/>
        <location filename="../base/bittorrent/session.cpp" line="582"/>
        <source>Local Peer Discovery support [%1]</source>
        <translation>Stöd för Local Peer Discovery [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="480"/>
        <source>PeX support [%1]</source>
        <translation>PeX-stöd [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1794"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Removed.</source>
        <translation>&apos;%1&apos; nått högsta förhållande. Borttagen.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1799"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Paused.</source>
        <translation>&apos;%1&apos; nått högsta förhållande. Pausad.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1819"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Removed.</source>
        <translation>&apos;%1&apos; nådde den högsta distributionstiden du ställde in. Togs bort.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1824"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Paused.</source>
        <translation>&apos;%1&apos; nådde den högsta distributionstiden du ställde in. Pausad.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2519"/>
        <source>qBittorrent didn&apos;t find an %1 local address to listen on</source>
        <comment>qBittorrent didn&apos;t find an IPv4 local address to listen on</comment>
        <translation>qBittorrent hittade inte en %1 lokal adress att lyssna på</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2547"/>
        <source>qBittorrent failed to listen on any interface port: %1. Reason: %2.</source>
        <comment>e.g: qBittorrent failed to listen on any interface port: TCP/6881. Reason: no such interface</comment>
        <translation>qBittorrent misslyckades med att lyssna på någon gränssnittsport: %1. Anledning: %2.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3593"/>
        <source>Tracker &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>Bevakaren &quot;%1&quot; lades till torrent &quot;%2&quot;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3605"/>
        <source>Tracker &apos;%1&apos; was deleted from torrent &apos;%2&apos;</source>
        <translation>Bevakaren &quot;%1&quot; togs bort från torrent &quot;%2&quot;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3622"/>
        <source>URL seed &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3629"/>
        <source>URL seed &apos;%1&apos; was removed from torrent &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3876"/>
        <source>Unable to resume torrent &apos;%1&apos;.</source>
        <comment>e.g: Unable to resume torrent &apos;hash&apos;.</comment>
        <translation>Kunde inte återuppta torrent &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3962"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3972"/>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4135"/>
        <source>&apos;%1&apos; restored.</source>
        <comment>&apos;torrent name&apos; restored.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4180"/>
        <source>Couldn&apos;t add torrent. Reason: %1</source>
        <translation>Kunde inte lägga till torrent. Anledning: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4156"/>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;torrent name&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; lades till i hämtningslistan.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4248"/>
        <source>An I/O error occurred, &apos;%1&apos; paused. %2</source>
        <translation>Ett I/O-fel inträffade, &quot;%1&quot; pausades. %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4258"/>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4264"/>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4274"/>
        <source>due to IP filter.</source>
        <comment>this peer was blocked due to ip filter.</comment>
        <translation>på grund av IP-filter.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4277"/>
        <source>due to port filter.</source>
        <comment>this peer was blocked due to port filter.</comment>
        <translation>på grund av portfilter.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4280"/>
        <source>due to i2p mixed mode restrictions.</source>
        <comment>this peer was blocked due to i2p mixed mode restrictions.</comment>
        <translation>på grund av i2p blandade lägesbegränsningar.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4283"/>
        <source>because it has a low port.</source>
        <comment>this peer was blocked because it has a low port.</comment>
        <translation>för att den har en låg port.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4328"/>
        <source>qBittorrent is successfully listening on interface %1 port: %2/%3</source>
        <comment>e.g: qBittorrent is successfully listening on interface 192.168.0.1 port: TCP/6881</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4365"/>
        <source>External IP: %1</source>
        <comment>e.g. External IP: 192.168.0.1</comment>
        <translation>Extern IP: %1</translation>
    </message>
</context>
<context>
    <name>BitTorrent::TorrentCreatorThread</name>
    <message>
        <location filename="../base/bittorrent/torrentcreatorthread.cpp" line="189"/>
        <source>create new torrent file failed</source>
        <translation>skapande av en ny torrentfil misslyckades</translation>
    </message>
</context>
<context>
    <name>BitTorrent::TorrentHandle</name>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1331"/>
        <source>Download first and last piece first: %1, torrent: &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1332"/>
        <source>On</source>
        <translation>På</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1332"/>
        <source>Off</source>
        <translation>Av</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1453"/>
        <source>Successfully moved torrent: %1. New path: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1488"/>
        <source>Could not move torrent: &apos;%1&apos;. Reason: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1670"/>
        <source>File sizes mismatch for torrent &apos;%1&apos;, pausing it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1673"/>
        <source>Fast resume data was rejected for torrent &apos;%1&apos;. Reason: %2. Checking again...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CategoryFilterModel</name>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="240"/>
        <source>Categories</source>
        <translation>Kategorier</translation>
    </message>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="394"/>
        <source>All</source>
        <translation>Alla</translation>
    </message>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="401"/>
        <source>Uncategorized</source>
        <translation>Okategoriserad</translation>
    </message>
</context>
<context>
    <name>CategoryFilterWidget</name>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="114"/>
        <source>Add category...</source>
        <translation>Lägg till kategori...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="122"/>
        <source>Add subcategory...</source>
        <translation>Lägg till underkategori...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="128"/>
        <source>Edit category...</source>
        <translation>Redigera kategori...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="133"/>
        <source>Remove category</source>
        <translation>Ta bort kategori</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="139"/>
        <source>Remove unused categories</source>
        <translation>Ta bort oanvända kategorier</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="146"/>
        <source>Resume torrents</source>
        <translation>Återuppta torrenter</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="151"/>
        <source>Pause torrents</source>
        <translation>Pausa torrenter</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="156"/>
        <source>Delete torrents</source>
        <translation>Ta bort torrenter</translation>
    </message>
</context>
<context>
    <name>CookiesDialog</name>
    <message>
        <location filename="../gui/cookiesdialog.ui" line="14"/>
        <source>Manage Cookies</source>
        <translation>Hantera kakor</translation>
    </message>
</context>
<context>
    <name>CookiesModel</name>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="49"/>
        <source>Domain</source>
        <translation>Domän</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="51"/>
        <source>Path</source>
        <translation>Filväg</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="53"/>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="55"/>
        <source>Value</source>
        <translation>Värde</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="57"/>
        <source>Expiration Date</source>
        <translation>Utgångsdatum</translation>
    </message>
</context>
<context>
    <name>DeletionConfirmationDialog</name>
    <message>
        <location filename="../gui/deletionconfirmationdialog.ui" line="20"/>
        <source>Deletion confirmation</source>
        <translation>Borttagningsbekräftelse</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.ui" line="67"/>
        <source>Remember choice</source>
        <translation>Kom ihåg valet</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.ui" line="91"/>
        <source>Also delete the files on the hard disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.h" line="52"/>
        <source>Are you sure you want to delete &apos;%1&apos; from the transfer list?</source>
        <comment>Are you sure you want to delete &apos;ubuntu-linux-iso&apos; from the transfer list?</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdialog.h" line="54"/>
        <source>Are you sure you want to delete these %1 torrents from the transfer list?</source>
        <comment>Are you sure you want to delete these 5 torrents from the transfer list?</comment>
        <translation>Är du säker på att du vill ta bort dessa %1 torrenter från överföringslistan?</translation>
    </message>
</context>
<context>
    <name>DownloadFromURLDialog</name>
    <message>
        <location filename="../gui/downloadfromurldialog.ui" line="14"/>
        <source>Download from URLs</source>
        <translation>Hämta från webbadresser</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.ui" line="26"/>
        <source>Add torrent links</source>
        <translation>Lägg till torrent-länkar</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.ui" line="48"/>
        <source>One link per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.cpp" line="64"/>
        <source>Download</source>
        <translation>Hämta</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.cpp" line="105"/>
        <source>No URL entered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldialog.cpp" line="105"/>
        <source>Please type at least one URL.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DownloadedPiecesBar</name>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="175"/>
        <source>White: Missing pieces</source>
        <translation>Vit: Saknade bitar</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="176"/>
        <source>Green: Partial pieces</source>
        <translation>Grön: Delvis färdiga bitar</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="177"/>
        <source>Blue: Completed pieces</source>
        <translation>Blå: Slutförda bitar</translation>
    </message>
</context>
<context>
    <name>ExecutionLogWidget</name>
    <message>
        <location filename="../gui/executionlogwidget.ui" line="39"/>
        <source>General</source>
        <translation>Allmänt</translation>
    </message>
    <message>
        <location filename="../gui/executionlogwidget.ui" line="45"/>
        <source>Blocked IPs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/executionlogwidget.cpp" line="106"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was blocked %2</source>
        <comment>x.y.z.w was blocked</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/executionlogwidget.cpp" line="108"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was banned</source>
        <comment>x.y.z.w was banned</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="49"/>
        <source>RSS feeds</source>
        <translation>RSS-kanaler</translation>
    </message>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="61"/>
        <location filename="../gui/rss/feedlistwidget.cpp" line="115"/>
        <source>Unread  (%1)</source>
        <translation>Olästa (%1)</translation>
    </message>
</context>
<context>
    <name>FileLogger</name>
    <message>
        <location filename="../app/filelogger.cpp" line="170"/>
        <source>An error occurred while trying to open the log file. Logging to file is disabled.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileSystemPathEdit</name>
    <message>
        <location filename="../gui/fspathedit.cpp" line="56"/>
        <source>...</source>
        <comment>Launch file dialog button text (brief)</comment>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="58"/>
        <source>&amp;Browse...</source>
        <comment>Launch file dialog button text (full)</comment>
        <translation>&amp;Bläddra...</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="60"/>
        <source>Choose a file</source>
        <comment>Caption for file open/save dialog</comment>
        <translation>Välj en fil</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="62"/>
        <source>Choose a folder</source>
        <comment>Caption for directory open dialog</comment>
        <translation>Välj en mapp</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="101"/>
        <source>Any file</source>
        <translation>Alla filer</translation>
    </message>
</context>
<context>
    <name>FilterParserThread</name>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="128"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="276"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="438"/>
        <source>I/O Error: Could not open IP filter file in read mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="213"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="344"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="353"/>
        <source>IP filter line %1 is malformed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="222"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="362"/>
        <source>IP filter line %1 is malformed. Start IP of the range is malformed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="231"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="371"/>
        <source>IP filter line %1 is malformed. End IP of the range is malformed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="239"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="379"/>
        <source>IP filter line %1 is malformed. One IP is IPv4 and the other is IPv6!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="253"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="392"/>
        <source>IP filter exception thrown for line %1. Exception is: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="263"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="402"/>
        <source>%1 extra IP filter parsing errors occurred.</source>
        <comment>513 extra IP filter parsing errors occurred.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="449"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="461"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="482"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="491"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="501"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="511"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="531"/>
        <source>Parsing Error: The filter file is not a valid PeerGuardian P2B file.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GeoIPDatabase</name>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="94"/>
        <location filename="../base/net/private/geoipdatabase.cpp" line="124"/>
        <source>Unsupported database file size.</source>
        <translation>Ostödd databasfilstorlek.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="223"/>
        <source>Metadata error: &apos;%1&apos; entry not found.</source>
        <translation>Metadatafel: &apos;%1&apos; inmatning hittades inte.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="224"/>
        <source>Metadata error: &apos;%1&apos; entry has invalid type.</source>
        <translation>Metadatafel: &apos;%1&apos; inmatningen har ogiltig typ.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="233"/>
        <source>Unsupported database version: %1.%2</source>
        <translation>Icke-stödd databasversion: %1.%2</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="240"/>
        <source>Unsupported IP version: %1</source>
        <translation>Icke-stödd IP-version: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="247"/>
        <source>Unsupported record size: %1</source>
        <translation>icke-stödd poststorlek: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="260"/>
        <source>Invalid database type: %1</source>
        <translation>Ogiltig databastyp: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="281"/>
        <source>Database corrupted: no data section found.</source>
        <translation>Databas skadad: ingen data sektion hittades.</translation>
    </message>
</context>
<context>
    <name>Http::Connection</name>
    <message>
        <location filename="../base/http/connection.cpp" line="69"/>
        <source>Http request size exceeds limiation, closing socket. Limit: %ld, IP: %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/http/connection.cpp" line="82"/>
        <source>Bad Http request, closing socket. IP: %s</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <location filename="../webui/extra_translations.h" line="37"/>
        <source>Exit qBittorrent</source>
        <translation>Avsluta qBittorrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="39"/>
        <source>Only one link per line</source>
        <translation>Endast en länk per rad</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="42"/>
        <source>Global upload rate limit must be greater than 0 or disabled.</source>
        <translation>Allmän begränsning för sändningshastighet måste vara större än 0 eller inaktiverad.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="43"/>
        <source>Global download rate limit must be greater than 0 or disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="44"/>
        <source>Alternative upload rate limit must be greater than 0 or disabled.</source>
        <translation>Alternativ begränsning för sändningshastighet måste vara större än 0 eller inaktiverad.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="45"/>
        <source>Alternative download rate limit must be greater than 0 or disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="46"/>
        <source>Maximum active downloads must be greater than -1.</source>
        <translation>Maximalt aktiva hämtningar måste vara större än -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="47"/>
        <source>Maximum active uploads must be greater than -1.</source>
        <translation>Maximalt aktiva sändningar måste vara större än -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="48"/>
        <source>Maximum active torrents must be greater than -1.</source>
        <translation>Maximalt aktiva torrenter måste vara större än -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="49"/>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>Gräns för högsta antal anslutningar måste vara större än 0 eller inaktiverad.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="50"/>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>Gräns för högsta antal anslutningar per torrent måste vara större än 0 eller inaktiverad.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="51"/>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>Gräns för högsta antal sändningsplatser per torrent måste vara större än 0 eller inaktiverad.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="52"/>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>Kunde inte spara programinställningarna. qBittorrent är antagligen inte nåbar.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="72"/>
        <source>IRC: #qbittorrent on Freenode</source>
        <translation>IRC: #qbittorrent på Freenode</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="73"/>
        <source>Invalid category name:
Please do not use any special characters in the category name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="74"/>
        <source>Unknown</source>
        <translation>Okänd</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="75"/>
        <source>Hard Disk</source>
        <translation>Hårddisk</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="76"/>
        <source>Share ratio limit must be between 0 and 9998.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="77"/>
        <source>Seeding time limit must be between 0 and 525600 minutes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="53"/>
        <source>The port used for incoming connections must be between 1 and 65535.</source>
        <translation>Porten som användas för inkommande anslutningar måste vara mellan 1 och 65535.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="54"/>
        <source>The port used for the Web UI must be between 1 and 65535.</source>
        <translation>Porten som används för webbgränssnittet måste vara mellan 1 och 65535</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="58"/>
        <source>Unable to log in, qBittorrent is probably unreachable.</source>
        <translation>Kunde inte logga in. qBittorrent är troligtvis inte nåbart.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="59"/>
        <source>Invalid Username or Password.</source>
        <translation>Felaktigt Användarnamn eller Lösenord</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="60"/>
        <source>Username</source>
        <translation>Användarnamn</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="61"/>
        <source>Password</source>
        <translation>Lösenord</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="62"/>
        <source>Login</source>
        <translation>Inloggning</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="63"/>
        <source>Original authors</source>
        <translation>Ursprungliga skapare</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="64"/>
        <source>Apply</source>
        <translation>Verkställ</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="65"/>
        <source>Add</source>
        <translation>Lägg till</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="94"/>
        <source>Upload Torrents</source>
        <comment>Upload torrent files to qBittorent using WebUI</comment>
        <translation>Skicka torrenter</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="66"/>
        <source>Save files to location:</source>
        <translation>Spara filer till platsen:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="67"/>
        <source>Cookie:</source>
        <translation>Kaka:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="68"/>
        <source>Type folder here</source>
        <translation>Ange mapp här</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="69"/>
        <source>More information</source>
        <translation>Mer information</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="70"/>
        <source>Information about certificates</source>
        <translation>Information om certifikat</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="71"/>
        <source>Save Files to</source>
        <translation>Spara filer till</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="78"/>
        <source>Set location</source>
        <translation>Ange plats</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="79"/>
        <source>Limit upload rate</source>
        <translation>Begränsa sändningshastighet</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="80"/>
        <source>Limit download rate</source>
        <translation>Begränsa hämtningshastighet</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="81"/>
        <source>Rename torrent</source>
        <translation>Byt namn på torrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="82"/>
        <source>Unable to create category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="86"/>
        <source>Other...</source>
        <comment>Save Files to: Watch Folder / Default Folder / Other...</comment>
        <translation>Annan...</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="87"/>
        <source>Monday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Måndag</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="88"/>
        <source>Tuesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Tisdag</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="89"/>
        <source>Wednesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Onsdag</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="90"/>
        <source>Thursday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Torsdag</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="91"/>
        <source>Friday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Fredag</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="92"/>
        <source>Saturday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Lördag</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="93"/>
        <source>Sunday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Söndag</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="36"/>
        <source>Logout</source>
        <translation>Logga ut</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="38"/>
        <source>Download Torrents from their URLs or Magnet links</source>
        <translation>Hämta torrenter från deras webbadresser eller magnetlänkar</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="40"/>
        <source>Upload local torrent</source>
        <translation>Skicka lokal torrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="41"/>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>Är du säker på att du vill ta bort de valda torrenterna från överföringslistan?</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="55"/>
        <source>Save</source>
        <translation>Spara</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="56"/>
        <source>qBittorrent client is not reachable</source>
        <translation>qBittorrent-klienten är inte nåbar</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="57"/>
        <source>qBittorrent has been shutdown.</source>
        <translation>qBittorrent har stängts av.</translation>
    </message>
</context>
<context>
    <name>IPSubnetWhitelistOptionsDialog</name>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="14"/>
        <source>List of whitelisted IP subnets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="53"/>
        <source>Example: 172.17.32.0/24, fdff:ffff:c8::/40</source>
        <translation>Exempel: 172.17.32.0/24, fdff:ffff:c8::/40</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="64"/>
        <source>Add subnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.ui" line="71"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.cpp" line="90"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../gui/ipsubnetwhitelistoptionsdialog.cpp" line="90"/>
        <source>The entered subnet is invalid.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LogListWidget</name>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="49"/>
        <source>Copy</source>
        <translation>Kopiera</translation>
    </message>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="50"/>
        <source>Clear</source>
        <translation>Rensa</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../gui/mainwindow.ui" line="43"/>
        <source>&amp;Edit</source>
        <translation>R&amp;edigera</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="68"/>
        <source>&amp;Tools</source>
        <translation>Ver&amp;ktyg</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="89"/>
        <source>&amp;File</source>
        <translation>&amp;Arkiv</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="58"/>
        <source>&amp;Help</source>
        <translation>&amp;Hjälp</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="72"/>
        <source>On Downloads &amp;Done</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="99"/>
        <source>&amp;View</source>
        <translation>&amp;Visa</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="180"/>
        <source>&amp;Options...</source>
        <translation>A&amp;lternativ...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="190"/>
        <source>&amp;Resume</source>
        <translation>&amp;Återuppta</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="223"/>
        <source>Torrent &amp;Creator</source>
        <translation>Torrent&amp;skapare</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="228"/>
        <source>Set Upload Limit...</source>
        <translation>Ställ in sändningsgräns...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="233"/>
        <source>Set Download Limit...</source>
        <translation>Ange gräns för hämtningshastighet...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="243"/>
        <source>Set Global Download Limit...</source>
        <translation>Ange gräns för global hämtningshastighet...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="248"/>
        <source>Set Global Upload Limit...</source>
        <translation>Ange gräns för global sändningshastighet...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="253"/>
        <source>Minimum Priority</source>
        <translation>Lägsta prioritet</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="261"/>
        <source>Top Priority</source>
        <translation>Högsta prioritet</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="269"/>
        <source>Decrease Priority</source>
        <translation>Minska prioritet</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="277"/>
        <source>Increase Priority</source>
        <translation>Öka prioritet</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="288"/>
        <location filename="../gui/mainwindow.ui" line="291"/>
        <source>Alternative Speed Limits</source>
        <translation>Alternativa hastighetsbegränsningar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="299"/>
        <source>&amp;Top Toolbar</source>
        <translation>&amp;Översta verktygsfältet</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="302"/>
        <source>Display Top Toolbar</source>
        <translation>Visa översta verktygsfältet</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="310"/>
        <source>Status &amp;Bar</source>
        <translation>Status&amp;fält</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="318"/>
        <source>S&amp;peed in Title Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="321"/>
        <source>Show Transfer Speed in Title Bar</source>
        <translation>Visa överföringshastighet i titelfältet</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="329"/>
        <source>&amp;RSS Reader</source>
        <translation>&amp;RSS-läsare</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="337"/>
        <source>Search &amp;Engine</source>
        <translation>Sök&amp;motor</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="342"/>
        <source>L&amp;ock qBittorrent</source>
        <translation>L&amp;ås qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="353"/>
        <source>Do&amp;nate!</source>
        <translation>Do&amp;nera!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="472"/>
        <source>Close Window</source>
        <translation>Stäng fönster</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="200"/>
        <source>R&amp;esume All</source>
        <translation>Återu&amp;ppta alla</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="424"/>
        <source>Manage Cookies...</source>
        <translation>Hantera kakor...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="427"/>
        <source>Manage stored network cookies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="443"/>
        <source>Normal Messages</source>
        <translation>Normala Meddelanden</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="451"/>
        <source>Information Messages</source>
        <translation>Informationsmeddelanden</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="459"/>
        <source>Warning Messages</source>
        <translation>Varningsmeddelanden</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="467"/>
        <source>Critical Messages</source>
        <translation>Kritiska Meddelanden</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="103"/>
        <source>&amp;Log</source>
        <translation>&amp;Logg</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="364"/>
        <source>&amp;Exit qBittorrent</source>
        <translation>&amp;Avsluta qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="372"/>
        <source>&amp;Suspend System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="380"/>
        <source>&amp;Hibernate System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="388"/>
        <source>S&amp;hutdown System</source>
        <translation>S&amp;täng av systemet</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="396"/>
        <source>&amp;Disabled</source>
        <translation>&amp;Inaktiverad</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="411"/>
        <source>&amp;Statistics</source>
        <translation>&amp;Statistik</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="416"/>
        <source>Check for Updates</source>
        <translation>Sök efter uppdateringar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="419"/>
        <source>Check for Program Updates</source>
        <translation>Sök efter programuppdateringar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="185"/>
        <source>&amp;About</source>
        <translation>&amp;Om</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="195"/>
        <source>&amp;Pause</source>
        <translation>&amp;Paus</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="210"/>
        <source>&amp;Delete</source>
        <translation>&amp;Ta bort</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="205"/>
        <source>P&amp;ause All</source>
        <translation>P&amp;ausa alla</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="167"/>
        <source>&amp;Add Torrent File...</source>
        <translation>&amp;Lägg till torrentfil...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="170"/>
        <source>Open</source>
        <translation>Öppna</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="175"/>
        <source>E&amp;xit</source>
        <translation>A&amp;vsluta</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="218"/>
        <source>Open URL</source>
        <translation>Öppna URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="238"/>
        <source>&amp;Documentation</source>
        <translation>&amp;Dokumentation</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="345"/>
        <source>Lock</source>
        <translation>Lås</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="401"/>
        <location filename="../gui/mainwindow.ui" line="435"/>
        <location filename="../gui/mainwindow.cpp" line="1687"/>
        <source>Show</source>
        <translation>Visa</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1891"/>
        <source>Check for program updates</source>
        <translation>Leta efter programuppdateringar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="215"/>
        <source>Add Torrent &amp;Link...</source>
        <translation>Lägg till torrent&amp;länk...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="356"/>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Donera om du tycker om qBittorrent!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1926"/>
        <location filename="../gui/mainwindow.cpp" line="1928"/>
        <source>Execution Log</source>
        <translation>Körningslogg</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="657"/>
        <source>Clear the password</source>
        <translation>Rensa lösenordet</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="235"/>
        <source>Filter torrent list...</source>
        <translation>Filtrera torrentlista...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="206"/>
        <source>&amp;Set Password</source>
        <translation>&amp;Ange lösenord</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="174"/>
        <source>Preferences</source>
        <translation>Inställningar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="208"/>
        <source>&amp;Clear Password</source>
        <translation>&amp;Rensa lösenord</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="261"/>
        <source>Transfers</source>
        <translation>Överföringar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="422"/>
        <location filename="../gui/mainwindow.cpp" line="1256"/>
        <source>qBittorrent is minimized to tray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="422"/>
        <location filename="../gui/mainwindow.cpp" line="1167"/>
        <location filename="../gui/mainwindow.cpp" line="1256"/>
        <source>This behavior can be changed in the settings. You won&apos;t be reminded again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="462"/>
        <source>Torrent file association</source>
        <translation>Associering av torrentfiler</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="463"/>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent är inte standardprogrammet för att öppna torrentfiler eller Magnet-länkar.
Vill du associera qBittorrent med torrentfiler och Magnet-länkar?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="546"/>
        <source>Icons Only</source>
        <translation>Endast ikoner</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="548"/>
        <source>Text Only</source>
        <translation>Endast text</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="550"/>
        <source>Text Alongside Icons</source>
        <translation>Text längs med ikoner</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="552"/>
        <source>Text Under Icons</source>
        <translation>Text under ikoner</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="554"/>
        <source>Follow System Style</source>
        <translation>Använd systemets utseende</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="641"/>
        <location filename="../gui/mainwindow.cpp" line="669"/>
        <location filename="../gui/mainwindow.cpp" line="1058"/>
        <source>UI lock password</source>
        <translation>Lösenord för gränssnittslåsning</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="641"/>
        <location filename="../gui/mainwindow.cpp" line="669"/>
        <location filename="../gui/mainwindow.cpp" line="1058"/>
        <source>Please type the UI lock password:</source>
        <translation>Ange lösenord för gränssnittslåsning:</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="645"/>
        <source>The password should contain at least 3 characters</source>
        <translation>Lösenordet bör innehålla minst 3 tecken</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="650"/>
        <source>Password update</source>
        <translation>Lösenordet har uppdaterats</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="650"/>
        <source>The UI lock password has been successfully updated</source>
        <translation>Lösenordet för gränssnittslåsning har uppdaterats</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="657"/>
        <source>Are you sure you want to clear the password?</source>
        <translation>Är du säker att du vill rensa lösenordet?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="711"/>
        <source>Use regular expressions</source>
        <translation>Använd reguljära uttryck</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="733"/>
        <source>Search</source>
        <translation>Sök</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="749"/>
        <source>Transfers (%1)</source>
        <translation>Överföringar (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="845"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="845"/>
        <source>Failed to add torrent: %1</source>
        <translation>Misslyckades med att lägga till torrent: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="852"/>
        <source>Torrent added</source>
        <translation>Torrent tillagd</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="852"/>
        <source>&apos;%1&apos; was added.</source>
        <comment>e.g: xxx.avi was added.</comment>
        <translation>&apos;%1&apos; tillades.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="858"/>
        <source>Download completion</source>
        <translation>Hämtningen är färdig</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="864"/>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>In-/ut-fel</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="957"/>
        <source>Recursive download confirmation</source>
        <translation>Bekräfta rekursiv hämtning</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="963"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="964"/>
        <source>No</source>
        <translation>Nej</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="965"/>
        <source>Never</source>
        <translation>Aldrig</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="990"/>
        <source>Global Upload Speed Limit</source>
        <translation>Allmän hastighetsgräns för sändning</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1005"/>
        <source>Global Download Speed Limit</source>
        <translation>Allmän hastighetsgräns för hämtning</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1081"/>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1167"/>
        <source>qBittorrent is closed to tray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1180"/>
        <source>Some files are currently transferring.</source>
        <translation>Några filer överförs för närvarande.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1180"/>
        <source>Are you sure you want to quit qBittorrent?</source>
        <translation>Är du säker på att du vill avsluta qBittorrent?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1182"/>
        <source>&amp;No</source>
        <translation>&amp;Nej</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1183"/>
        <source>&amp;Yes</source>
        <translation>&amp;Ja</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1184"/>
        <source>&amp;Always Yes</source>
        <translation>&amp;Alltid Ja</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1586"/>
        <source>%1/s</source>
        <comment>s is a shorthand for seconds</comment>
        <translation>%1/s</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1801"/>
        <source>Couldn&apos;t determine your Python version. Search engine disabled.</source>
        <translation>Det gick inte att bestämma din Python-version. Sökmotor inaktiverad.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1816"/>
        <source>Old Python Interpreter</source>
        <translation>Gammal Python-tolk</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1816"/>
        <source>Your Python version (%1) is outdated. Please upgrade to latest version for search engines to work.
Minimum requirement: 2.7.9 / 3.3.0.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1873"/>
        <source>qBittorrent Update Available</source>
        <translation>qBittorrent uppdatering tillgänglig</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1885"/>
        <source>Already Using the Latest qBittorrent Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1801"/>
        <source>Undetermined Python version</source>
        <translation>Ospecificerad Python-version</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="858"/>
        <source>&apos;%1&apos; has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>&quot;&apos;%1&quot; har hämtats.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="865"/>
        <source>An I/O error occurred for torrent &apos;%1&apos;.
 Reason: %2</source>
        <comment>e.g: An error occurred for torrent &apos;xxx.avi&apos;.
 Reason: disk is full.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="958"/>
        <source>The torrent &apos;%1&apos; contains torrent files, do you want to proceed with their download?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="980"/>
        <source>Couldn&apos;t download file at URL &apos;%1&apos;, reason: %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1792"/>
        <source>Python found in %1: %2</source>
        <comment>Python found in PATH: /usr/local/bin:/usr/bin:/etc/bin</comment>
        <translation>Python hittades i %1: %2</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1829"/>
        <location filename="../gui/mainwindow.cpp" line="1841"/>
        <source>Missing Python Interpreter</source>
        <translation>Python-tolk saknas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1830"/>
        <source>Python is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>Python krävs för att använda sökmotorn, men det verkar inte vara installerat.
Vill du installera det nu?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1841"/>
        <source>Python is required to use the search engine but it does not seem to be installed.</source>
        <translation>Python krävs för att använda sökmotorn, men det verkar inte vara installerat.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1874"/>
        <source>A new version is available.</source>
        <translation>En ny version är tillgänglig.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1875"/>
        <source>Do you want to download %1?</source>
        <translation>Vill du hämta %1?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1876"/>
        <source>Open changelog...</source>
        <translation>Öppna ändringslogg...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1886"/>
        <source>No updates available.
You are already using the latest version.</source>
        <translation>Inga uppdateringar tillgängliga.
Du använder redan den senaste versionen.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1890"/>
        <source>&amp;Check for Updates</source>
        <translation>&amp;Sök efter uppdateringar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2053"/>
        <source>Checking for Updates...</source>
        <translation>Söker efter uppdateringar...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2054"/>
        <source>Already checking for program updates in the background</source>
        <translation>Leta redan efter programuppdateringar i bakgrunden</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2070"/>
        <source>Python found in &apos;%1&apos;</source>
        <translation>Python hittades i &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2139"/>
        <source>Download error</source>
        <translation>Hämtningsfel</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2139"/>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>Python-installationen kunde inte hämtas. Anledning: %1.
Installera den manuellt.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="645"/>
        <location filename="../gui/mainwindow.cpp" line="1073"/>
        <source>Invalid password</source>
        <translation>Ogiltigt lösenord</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="682"/>
        <location filename="../gui/mainwindow.cpp" line="693"/>
        <location filename="../gui/mainwindow.cpp" line="695"/>
        <source>RSS (%1)</source>
        <translation>RSS (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="979"/>
        <source>URL download error</source>
        <translation>Webbadress-hämtningsfel</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1073"/>
        <source>The password is invalid</source>
        <translation>Lösenordet är ogiltigt</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1571"/>
        <location filename="../gui/mainwindow.cpp" line="1578"/>
        <source>DL speed: %1</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Hämtning: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1574"/>
        <location filename="../gui/mainwindow.cpp" line="1580"/>
        <source>UP speed: %1</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Sändning: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1593"/>
        <source>[D: %1, U: %2] qBittorrent %3</source>
        <comment>D = Download; U = Upload; %3 is qBittorrent version</comment>
        <translation>[N: %1/s, U: %2/s] qBittorrent %3</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1687"/>
        <source>Hide</source>
        <translation>Dölj</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1178"/>
        <source>Exiting qBittorrent</source>
        <translation>Avslutar qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1382"/>
        <source>Open Torrent Files</source>
        <translation>Öppna torrent-filer</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1383"/>
        <source>Torrent Files</source>
        <translation>Torrent-filer</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1433"/>
        <source>Options were saved successfully.</source>
        <translation>Inställningarna har sparats.</translation>
    </message>
</context>
<context>
    <name>Net::DNSUpdater</name>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="188"/>
        <source>Your dynamic DNS was successfully updated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="193"/>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="203"/>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="209"/>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="215"/>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="222"/>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="229"/>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="249"/>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="260"/>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="271"/>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Net::DownloadHandler</name>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="127"/>
        <source>I/O Error</source>
        <translation>I/O-fel</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="140"/>
        <source>The file size is %1. It exceeds the download limit of %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="174"/>
        <source>Unexpected redirect to magnet URI.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="206"/>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="208"/>
        <source>The operation was canceled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="210"/>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="212"/>
        <source>The connection to the remote server timed out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="214"/>
        <source>SSL/TLS handshake failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="216"/>
        <source>The remote server refused the connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="218"/>
        <source>The connection to the proxy server was refused</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="220"/>
        <source>The proxy server closed the connection prematurely</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="222"/>
        <source>The proxy host name was not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="224"/>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="226"/>
        <source>The proxy requires authentication in order to honor the request but did not accept any credentials offered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="228"/>
        <source>The access to the remote content was denied (401)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="230"/>
        <source>The operation requested on the remote content is not permitted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="232"/>
        <source>The remote content was not found at the server (404)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="234"/>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="236"/>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="238"/>
        <source>The requested operation is invalid for this protocol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="240"/>
        <source>An unknown network-related error was detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="242"/>
        <source>An unknown proxy-related error was detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="244"/>
        <source>An unknown error related to the remote content was detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="246"/>
        <source>A breakdown in protocol was detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="248"/>
        <source>Unknown error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Net::GeoIPManager</name>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="104"/>
        <location filename="../base/net/geoipmanager.cpp" line="434"/>
        <source>GeoIP database loaded. Type: %1. Build time: %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="108"/>
        <location filename="../base/net/geoipmanager.cpp" line="455"/>
        <source>Couldn&apos;t load GeoIP database. Reason: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="381"/>
        <source>Venezuela, Bolivarian Republic of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="384"/>
        <source>Viet Nam</source>
        <translation>Vietnam</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="394"/>
        <location filename="../base/net/geoipmanager.cpp" line="398"/>
        <source>N/A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="144"/>
        <source>Andorra</source>
        <translation>Andorra</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="145"/>
        <source>United Arab Emirates</source>
        <translation>Förenade Arabemiraten</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="146"/>
        <source>Afghanistan</source>
        <translation>Afghanistan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="147"/>
        <source>Antigua and Barbuda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="148"/>
        <source>Anguilla</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="149"/>
        <source>Albania</source>
        <translation>Albanien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="150"/>
        <source>Armenia</source>
        <translation>Armenien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="151"/>
        <source>Angola</source>
        <translation>Angola</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="152"/>
        <source>Antarctica</source>
        <translation>Antarktis</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="153"/>
        <source>Argentina</source>
        <translation>Argentina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="154"/>
        <source>American Samoa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="155"/>
        <source>Austria</source>
        <translation>Österrike</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="156"/>
        <source>Australia</source>
        <translation>Australien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="157"/>
        <source>Aruba</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="159"/>
        <source>Azerbaijan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="160"/>
        <source>Bosnia and Herzegovina</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="161"/>
        <source>Barbados</source>
        <translation>Barbados</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="162"/>
        <source>Bangladesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="163"/>
        <source>Belgium</source>
        <translation>Belgien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="164"/>
        <source>Burkina Faso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="165"/>
        <source>Bulgaria</source>
        <translation>Bulgarien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="166"/>
        <source>Bahrain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="167"/>
        <source>Burundi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="168"/>
        <source>Benin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="170"/>
        <source>Bermuda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="171"/>
        <source>Brunei Darussalam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="174"/>
        <source>Brazil</source>
        <translation>Brasilien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="175"/>
        <source>Bahamas</source>
        <translation>Bahamas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="176"/>
        <source>Bhutan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="177"/>
        <source>Bouvet Island</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="178"/>
        <source>Botswana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="179"/>
        <source>Belarus</source>
        <translation>Vitryssland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="180"/>
        <source>Belize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="181"/>
        <source>Canada</source>
        <translation>Kanada</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="182"/>
        <source>Cocos (Keeling) Islands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="183"/>
        <source>Congo, The Democratic Republic of the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="184"/>
        <source>Central African Republic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="185"/>
        <source>Congo</source>
        <translation>Kongo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="186"/>
        <source>Switzerland</source>
        <translation>Schweiz</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="188"/>
        <source>Cook Islands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="189"/>
        <source>Chile</source>
        <translation>Chile</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="190"/>
        <source>Cameroon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="191"/>
        <source>China</source>
        <translation>Kina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="192"/>
        <source>Colombia</source>
        <translation>Colombia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="193"/>
        <source>Costa Rica</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="194"/>
        <source>Cuba</source>
        <translation>Kuba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="195"/>
        <source>Cape Verde</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="196"/>
        <source>Curacao</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="197"/>
        <source>Christmas Island</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="198"/>
        <source>Cyprus</source>
        <translation>Cypern</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="199"/>
        <source>Czech Republic</source>
        <translation>Tjeckien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="200"/>
        <source>Germany</source>
        <translation>Tyskland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="201"/>
        <source>Djibouti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="202"/>
        <source>Denmark</source>
        <translation>Danmark</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="203"/>
        <source>Dominica</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="204"/>
        <source>Dominican Republic</source>
        <translation>Dominikanska republiken</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="205"/>
        <source>Algeria</source>
        <translation>Algeriet</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="206"/>
        <source>Ecuador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="207"/>
        <source>Estonia</source>
        <translation>Estland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="208"/>
        <source>Egypt</source>
        <translation>Egypten</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="209"/>
        <source>Western Sahara</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="210"/>
        <source>Eritrea</source>
        <translation>Eritrea</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="211"/>
        <source>Spain</source>
        <translation>Spanien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="212"/>
        <source>Ethiopia</source>
        <translation>Etiopien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="213"/>
        <source>Finland</source>
        <translation>Finland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="214"/>
        <source>Fiji</source>
        <translation>Fiji</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="215"/>
        <source>Falkland Islands (Malvinas)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="216"/>
        <source>Micronesia, Federated States of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="217"/>
        <source>Faroe Islands</source>
        <translation>Färöarna</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="218"/>
        <source>France</source>
        <translation>Frankrike</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="219"/>
        <source>Gabon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="220"/>
        <source>United Kingdom</source>
        <translation>Storbritannien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="221"/>
        <source>Grenada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="222"/>
        <source>Georgia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="223"/>
        <source>French Guiana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="225"/>
        <source>Ghana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="226"/>
        <source>Gibraltar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="227"/>
        <source>Greenland</source>
        <translation>Grönland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="228"/>
        <source>Gambia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="229"/>
        <source>Guinea</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="230"/>
        <source>Guadeloupe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="231"/>
        <source>Equatorial Guinea</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="232"/>
        <source>Greece</source>
        <translation>Grekland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="233"/>
        <source>South Georgia and the South Sandwich Islands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="234"/>
        <source>Guatemala</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="235"/>
        <source>Guam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="236"/>
        <source>Guinea-Bissau</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="237"/>
        <source>Guyana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="238"/>
        <source>Hong Kong</source>
        <translation>Hong Kong</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="239"/>
        <source>Heard Island and McDonald Islands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="240"/>
        <source>Honduras</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="241"/>
        <source>Croatia</source>
        <translation>Kroatien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="242"/>
        <source>Haiti</source>
        <translation>Haiti</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="243"/>
        <source>Hungary</source>
        <translation>Ungern</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="244"/>
        <source>Indonesia</source>
        <translation>Indonesien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="245"/>
        <source>Ireland</source>
        <translation>Irland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="246"/>
        <source>Israel</source>
        <translation>Israel</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="248"/>
        <source>India</source>
        <translation>Indien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="249"/>
        <source>British Indian Ocean Territory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="250"/>
        <source>Iraq</source>
        <translation>Irak</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="251"/>
        <source>Iran, Islamic Republic of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="252"/>
        <source>Iceland</source>
        <translation>Island</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="253"/>
        <source>Italy</source>
        <translation>Italien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="255"/>
        <source>Jamaica</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="256"/>
        <source>Jordan</source>
        <translation>Jordanien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="257"/>
        <source>Japan</source>
        <translation>Japan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="258"/>
        <source>Kenya</source>
        <translation>Kenya</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="259"/>
        <source>Kyrgyzstan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="260"/>
        <source>Cambodia</source>
        <translation>Kambodja</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="261"/>
        <source>Kiribati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="262"/>
        <source>Comoros</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="263"/>
        <source>Saint Kitts and Nevis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="264"/>
        <source>Korea, Democratic People&apos;s Republic of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="265"/>
        <source>Korea, Republic of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="266"/>
        <source>Kuwait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="267"/>
        <source>Cayman Islands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="268"/>
        <source>Kazakhstan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="269"/>
        <source>Lao People&apos;s Democratic Republic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="270"/>
        <source>Lebanon</source>
        <translation>Libanon</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="271"/>
        <source>Saint Lucia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="272"/>
        <source>Liechtenstein</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="273"/>
        <source>Sri Lanka</source>
        <translation>Sri Lanka</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="274"/>
        <source>Liberia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="275"/>
        <source>Lesotho</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="276"/>
        <source>Lithuania</source>
        <translation>Litauen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="277"/>
        <source>Luxembourg</source>
        <translation>Luxemburg</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="278"/>
        <source>Latvia</source>
        <translation>Lettland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="280"/>
        <source>Morocco</source>
        <translation>Marocko</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="281"/>
        <source>Monaco</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="282"/>
        <source>Moldova, Republic of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="285"/>
        <source>Madagascar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="286"/>
        <source>Marshall Islands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="288"/>
        <source>Mali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="289"/>
        <source>Myanmar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="290"/>
        <source>Mongolia</source>
        <translation>Mongoliet</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="292"/>
        <source>Northern Mariana Islands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="293"/>
        <source>Martinique</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="294"/>
        <source>Mauritania</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="295"/>
        <source>Montserrat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="296"/>
        <source>Malta</source>
        <translation>Malta</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="297"/>
        <source>Mauritius</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="298"/>
        <source>Maldives</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="299"/>
        <source>Malawi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="300"/>
        <source>Mexico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="301"/>
        <source>Malaysia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="302"/>
        <source>Mozambique</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="303"/>
        <source>Namibia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="304"/>
        <source>New Caledonia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="305"/>
        <source>Niger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="306"/>
        <source>Norfolk Island</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="307"/>
        <source>Nigeria</source>
        <translation>Nigeria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="308"/>
        <source>Nicaragua</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="309"/>
        <source>Netherlands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="310"/>
        <source>Norway</source>
        <translation>Norge</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="311"/>
        <source>Nepal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="312"/>
        <source>Nauru</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="313"/>
        <source>Niue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="314"/>
        <source>New Zealand</source>
        <translation>Nya Zeeland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="315"/>
        <source>Oman</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="316"/>
        <source>Panama</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="317"/>
        <source>Peru</source>
        <translation>Peru</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="318"/>
        <source>French Polynesia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="319"/>
        <source>Papua New Guinea</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="320"/>
        <source>Philippines</source>
        <translation>Filippinerna</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="321"/>
        <source>Pakistan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="322"/>
        <source>Poland</source>
        <translation>Polen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="323"/>
        <source>Saint Pierre and Miquelon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="325"/>
        <source>Puerto Rico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="327"/>
        <source>Portugal</source>
        <translation>Portugal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="328"/>
        <source>Palau</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="329"/>
        <source>Paraguay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="330"/>
        <source>Qatar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="331"/>
        <source>Reunion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="332"/>
        <source>Romania</source>
        <translation>Rumänien</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="334"/>
        <source>Russian Federation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="335"/>
        <source>Rwanda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="336"/>
        <source>Saudi Arabia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="337"/>
        <source>Solomon Islands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="338"/>
        <source>Seychelles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="339"/>
        <source>Sudan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="340"/>
        <source>Sweden</source>
        <translation>Sverige</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="341"/>
        <source>Singapore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="343"/>
        <source>Slovenia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="344"/>
        <source>Svalbard and Jan Mayen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="345"/>
        <source>Slovakia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="346"/>
        <source>Sierra Leone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="347"/>
        <source>San Marino</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="348"/>
        <source>Senegal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="349"/>
        <source>Somalia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="350"/>
        <source>Suriname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="352"/>
        <source>Sao Tome and Principe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="353"/>
        <source>El Salvador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="355"/>
        <source>Syrian Arab Republic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="356"/>
        <source>Swaziland</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="357"/>
        <source>Turks and Caicos Islands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="358"/>
        <source>Chad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="359"/>
        <source>French Southern Territories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="360"/>
        <source>Togo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="361"/>
        <source>Thailand</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="362"/>
        <source>Tajikistan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="363"/>
        <source>Tokelau</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="365"/>
        <source>Turkmenistan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="366"/>
        <source>Tunisia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="367"/>
        <source>Tonga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="423"/>
        <source>Could not decompress GeoIP database file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="364"/>
        <source>Timor-Leste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="172"/>
        <source>Bolivia, Plurinational State of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="173"/>
        <source>Bonaire, Sint Eustatius and Saba</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="187"/>
        <source>Cote d&apos;Ivoire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="279"/>
        <source>Libya</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="284"/>
        <source>Saint Martin (French part)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="287"/>
        <source>Macedonia, The Former Yugoslav Republic of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="291"/>
        <source>Macao</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="324"/>
        <source>Pitcairn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="326"/>
        <source>Palestine, State of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="342"/>
        <source>Saint Helena, Ascension and Tristan da Cunha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="351"/>
        <source>South Sudan</source>
        <translation>Sydsudan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="354"/>
        <source>Sint Maarten (Dutch part)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="368"/>
        <source>Turkey</source>
        <translation>Turkiet</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="369"/>
        <source>Trinidad and Tobago</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="370"/>
        <source>Tuvalu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="371"/>
        <source>Taiwan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="372"/>
        <source>Tanzania, United Republic of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="373"/>
        <source>Ukraine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="374"/>
        <source>Uganda</source>
        <translation>Uganda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="375"/>
        <source>United States Minor Outlying Islands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="376"/>
        <source>United States</source>
        <translation>Förenta staterna</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="377"/>
        <source>Uruguay</source>
        <translation>Uruguay</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="378"/>
        <source>Uzbekistan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="379"/>
        <source>Holy See (Vatican City State)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="380"/>
        <source>Saint Vincent and the Grenadines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="382"/>
        <source>Virgin Islands, British</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="383"/>
        <source>Virgin Islands, U.S.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="385"/>
        <source>Vanuatu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="386"/>
        <source>Wallis and Futuna</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="387"/>
        <source>Samoa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="388"/>
        <source>Yemen</source>
        <translation>Jemen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="389"/>
        <source>Mayotte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="333"/>
        <source>Serbia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="390"/>
        <source>South Africa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="391"/>
        <source>Zambia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="283"/>
        <source>Montenegro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="392"/>
        <source>Zimbabwe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="158"/>
        <source>Aland Islands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="224"/>
        <source>Guernsey</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="247"/>
        <source>Isle of Man</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="254"/>
        <source>Jersey</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="169"/>
        <source>Saint Barthelemy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="444"/>
        <source>Couldn&apos;t save downloaded GeoIP database file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="447"/>
        <source>Successfully updated GeoIP database.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="462"/>
        <source>Couldn&apos;t download GeoIP database file. Reason: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Net::PortForwarder</name>
    <message>
        <location filename="../base/net/portforwarder.cpp" line="129"/>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>UPnP / NAT-PMP-stöd [PÅ]</translation>
    </message>
    <message>
        <location filename="../base/net/portforwarder.cpp" line="145"/>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>UPnP / NAT-PMP-stöd [AV]</translation>
    </message>
</context>
<context>
    <name>Net::Smtp</name>
    <message>
        <location filename="../base/net/smtp.cpp" line="506"/>
        <source>Email Notification Error:</source>
        <translation>E-postaviseringsfel:</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="../gui/optionsdialog.ui" line="14"/>
        <source>Options</source>
        <translation>Alternativ</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="52"/>
        <source>Behavior</source>
        <translation>Beteende</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="57"/>
        <source>Downloads</source>
        <translation>Hämtningar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="62"/>
        <source>Connection</source>
        <translation>Anslutning</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="67"/>
        <source>Speed</source>
        <translation>Hastighet</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="72"/>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="77"/>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="82"/>
        <source>Web UI</source>
        <translation>Webbgränssnitt</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="87"/>
        <source>Advanced</source>
        <translation>Avancerat</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="133"/>
        <source>Language</source>
        <translation>Språk</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="141"/>
        <source>User Interface Language:</source>
        <translation>Användargränsspråk:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="169"/>
        <source>(Requires restart)</source>
        <translation>(Kräver omstart)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="197"/>
        <source>Transfer List</source>
        <translation>Överföringslista</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="203"/>
        <source>Confirm when deleting torrents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="213"/>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="225"/>
        <source>Hide zero and infinity values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="233"/>
        <source>Always</source>
        <translation>Alltid</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="238"/>
        <source>Paused torrents only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="267"/>
        <source>Action on double-click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="276"/>
        <source>Downloading torrents:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="293"/>
        <location filename="../gui/optionsdialog.ui" line="319"/>
        <source>Start / Stop Torrent</source>
        <translation>Starta/Stoppa torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="298"/>
        <location filename="../gui/optionsdialog.ui" line="324"/>
        <source>Open destination folder</source>
        <translation type="unfinished">Öppna målmapp</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="303"/>
        <location filename="../gui/optionsdialog.ui" line="329"/>
        <source>No action</source>
        <translation>Ingen åtgärd</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="311"/>
        <source>Completed torrents:</source>
        <translation>Färdiga torrenter:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="343"/>
        <source>Desktop</source>
        <translation>Skrivbord</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="349"/>
        <source>Start qBittorrent on Windows start up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="356"/>
        <source>Show splash screen on start up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="366"/>
        <source>Start qBittorrent minimized</source>
        <translation>Starta qBittorrent minimerad</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="373"/>
        <source>Confirmation on exit when torrents are active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="383"/>
        <source>Confirmation on auto-exit when downloads finish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="545"/>
        <source> KiB</source>
        <translation> KiB</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1125"/>
        <source>Email notification &amp;upon download completion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1220"/>
        <source>Run e&amp;xternal program on torrent completion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1706"/>
        <source>IP Fi&amp;ltering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1896"/>
        <source>Schedule &amp;the use of alternative rate limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2250"/>
        <source>(&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;More information&lt;/a&gt;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2278"/>
        <source>&amp;Torrent Queueing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2628"/>
        <source>Seed torrents until their seeding time reaches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2661"/>
        <source>A&amp;utomatically add these trackers to new downloads:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2734"/>
        <source>RSS Reader</source>
        <translation>RSS-läsare</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2740"/>
        <source>Enable fetching RSS feeds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2749"/>
        <source>Feeds refresh interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2759"/>
        <source>Maximum number of articles per feed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2593"/>
        <location filename="../gui/optionsdialog.ui" line="2769"/>
        <source> min</source>
        <extracomment>minutes</extracomment>
        <translation> min</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2813"/>
        <source>RSS Torrent Auto Downloader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2819"/>
        <source>Enable auto downloading of RSS torrents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2826"/>
        <source>Edit auto downloading rules...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2896"/>
        <source>Web User Interface (Remote control)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2910"/>
        <source>IP address:</source>
        <translation>IP-adress:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2917"/>
        <source>IP address that the Web UI will bind to.
Specify an IPv4 or IPv6 address. You can specify &quot;0.0.0.0&quot; for any IPv4 address,
&quot;::&quot; for any IPv6 address, or &quot;*&quot; for both IPv4 and IPv6.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2950"/>
        <source>Server domains:</source>
        <translation>Serverdomäner:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2957"/>
        <source>Whitelist for filtering HTTP Host header values.
In order to defend against DNS rebinding attack,
you should put in domain names used by WebUI server.

Use &apos;;&apos; to split multiple entries. Can use wildcard &apos;*&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2980"/>
        <source>&amp;Use HTTPS instead of HTTP</source>
        <translation>&amp;Använd HTTPS istället för HTTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3111"/>
        <source>Bypass authentication for clients on localhost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3118"/>
        <source>Bypass authentication for clients in whitelisted IP subnets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3131"/>
        <source>IP subnet whitelist...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3194"/>
        <source>Upda&amp;te my dynamic domain name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="402"/>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Minimera qBittorrent till aviseringsområdet</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="412"/>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation>Stäng qBittorrent till aviseringsområdet</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="421"/>
        <source>Tray icon style:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="429"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="434"/>
        <source>Monochrome (Dark theme)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="439"/>
        <source>Monochrome (Light theme)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="452"/>
        <source>File association</source>
        <translation>Filassociation</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="458"/>
        <source>Use qBittorrent for .torrent files</source>
        <translation>Använd qBittorrent för .torrent-filer</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="465"/>
        <source>Use qBittorrent for magnet links</source>
        <translation>Använd qBittorrent för magnetlänkar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="478"/>
        <source>Power Management</source>
        <translation>Energihantering</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="521"/>
        <source>Save path:</source>
        <translation>Spara sökväg:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="538"/>
        <source>Backup the log file after:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="581"/>
        <source>Delete backup logs older than:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="605"/>
        <source>days</source>
        <comment>Delete backup logs older than 10 months</comment>
        <translation>dagar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="610"/>
        <source>months</source>
        <comment>Delete backup logs older than 10 months</comment>
        <translation>månader</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="615"/>
        <source>years</source>
        <comment>Delete backup logs older than 10 years</comment>
        <translation>år</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="689"/>
        <source>When adding a torrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="707"/>
        <source>Bring torrent dialog to the front</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="730"/>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="737"/>
        <source>Should the .torrent file be deleted after adding it</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="752"/>
        <source>Also delete .torrent files whose addition was cancelled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="755"/>
        <source>Also when addition is cancelled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="777"/>
        <source>Warning! Data loss possible!</source>
        <translation>Varning! Dataförlust möjlig!</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="813"/>
        <source>Saving Management</source>
        <translation>Sparar hantering</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="821"/>
        <source>Default Torrent Management Mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="833"/>
        <source>Automatic mode means that various torrent properties (e.g. save path) will be decided by the associated category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="837"/>
        <source>Manual</source>
        <translation>Handbok</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="842"/>
        <source>Automatic</source>
        <translation>Automatisk</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="865"/>
        <source>When Torrent Category changed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="875"/>
        <source>Relocate torrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="880"/>
        <source>Switch torrent to Manual Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="903"/>
        <source>When Default Save Path changed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="916"/>
        <location filename="../gui/optionsdialog.ui" line="957"/>
        <source>Relocate affected torrents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="921"/>
        <location filename="../gui/optionsdialog.ui" line="962"/>
        <source>Switch affected torrents to Manual Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="944"/>
        <source>When Category changed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="987"/>
        <source>Use Subcategories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1006"/>
        <source>Default Save Path:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1020"/>
        <source>Keep incomplete torrents in:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1013"/>
        <source>Copy .torrent files to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="393"/>
        <source>Show &amp;qBittorrent in notification area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="501"/>
        <source>&amp;Log file</source>
        <translation>&amp;Loggfil</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="695"/>
        <source>Display &amp;torrent content and some options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="720"/>
        <source>Create subfolder for torrents with multiple files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="740"/>
        <source>De&amp;lete .torrent files afterwards </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="999"/>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="792"/>
        <source>Pre-allocate disk space for all files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="484"/>
        <source>Inhibit system sleep when torrents are downloading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="491"/>
        <source>Inhibit system sleep when torrents are seeding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="799"/>
        <source>Append .!qB extension to incomplete files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="806"/>
        <source>Enable recursive download dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1041"/>
        <source>Automatically add torrents from:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1088"/>
        <source>Add entry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1098"/>
        <source>Remove entry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1149"/>
        <source>SMTP server:</source>
        <translation>SMTP-server:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1171"/>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Den här servern kräver en säker anslutning (SSL)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1178"/>
        <location filename="../gui/optionsdialog.ui" line="3079"/>
        <source>Authentication</source>
        <translation>Autentisering</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1190"/>
        <location filename="../gui/optionsdialog.ui" line="1667"/>
        <location filename="../gui/optionsdialog.ui" line="3138"/>
        <location filename="../gui/optionsdialog.ui" line="3252"/>
        <source>Username:</source>
        <translation>Användarnamn:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1200"/>
        <location filename="../gui/optionsdialog.ui" line="1677"/>
        <location filename="../gui/optionsdialog.ui" line="3145"/>
        <location filename="../gui/optionsdialog.ui" line="3266"/>
        <source>Password:</source>
        <translation>Lösenord:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1288"/>
        <source>Enabled protocol:</source>
        <translation>Aktiverat protokoll:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1296"/>
        <source>TCP and μTP</source>
        <translation>TCP och μTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1316"/>
        <source>Listening Port</source>
        <translation>Lyssningsport</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1324"/>
        <source>Port used for incoming connections:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1344"/>
        <source>Random</source>
        <translation>Slumpmässig</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1366"/>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1376"/>
        <source>Use different port on each startup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1386"/>
        <source>Connections Limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1402"/>
        <source>Maximum number of connections per torrent:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1412"/>
        <source>Global maximum number of connections:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1451"/>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Högsta antal sändningsplatser per torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1461"/>
        <source>Global maximum number of upload slots:</source>
        <translation>Allmänt högsta antal sändningsplatser:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1500"/>
        <source>Proxy Server</source>
        <translation>Proxyserver</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1508"/>
        <source>Type:</source>
        <translation>Typ:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1516"/>
        <source>(None)</source>
        <translation>(Inga)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1521"/>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1526"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1531"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1542"/>
        <source>Host:</source>
        <translation>Värd:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1562"/>
        <location filename="../gui/optionsdialog.ui" line="2926"/>
        <source>Port:</source>
        <translation>Port:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1590"/>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1593"/>
        <source>Use proxy for peer connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1602"/>
        <source>Disable connections not supported by proxies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1612"/>
        <source>(&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Disable-connections-not-supported-by-proxies&quot;&gt;More information&lt;/a&gt;)</source>
        <translation>(&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Disable-connections-not-supported-by-proxies&quot;&gt;Mer information&lt;/a&gt;)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1637"/>
        <source>RSS feeds, search engine, software updates or anything else other than torrent transfers and related operations (such as peer exchanges) will use a direct connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1640"/>
        <source>Use proxy only for torrents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1653"/>
        <source>A&amp;uthentication</source>
        <translation>A&amp;utentisering</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1693"/>
        <source>Info: The password is saved unencrypted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1714"/>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1730"/>
        <source>Reload the filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1745"/>
        <source>Manually banned IP addresses...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1752"/>
        <source>Apply to trackers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1810"/>
        <source>Global Rate Limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1819"/>
        <location filename="../gui/optionsdialog.ui" line="1845"/>
        <location filename="../gui/optionsdialog.ui" line="2024"/>
        <location filename="../gui/optionsdialog.ui" line="2043"/>
        <location filename="../gui/optionsdialog.ui" line="2417"/>
        <location filename="../gui/optionsdialog.ui" line="2430"/>
        <source> KiB/s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1835"/>
        <location filename="../gui/optionsdialog.ui" line="2007"/>
        <source>Upload:</source>
        <translation>Skickat:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1864"/>
        <location filename="../gui/optionsdialog.ui" line="2014"/>
        <source>Download:</source>
        <translation>Hämtning:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1887"/>
        <source>Alternative Rate Limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1162"/>
        <location filename="../gui/optionsdialog.ui" line="1908"/>
        <source>From:</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>Från:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1142"/>
        <location filename="../gui/optionsdialog.ui" line="1932"/>
        <source>To:</source>
        <extracomment>time1 to time2</extracomment>
        <translation>Till:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1959"/>
        <source>When:</source>
        <translation>När:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1973"/>
        <source>Every day</source>
        <translation>Varje dag</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1978"/>
        <source>Weekdays</source>
        <translation>Vardagar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="1983"/>
        <source>Weekends</source>
        <translation>Helger</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2075"/>
        <source>Rate Limits Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2095"/>
        <source>Apply rate limit to peers on LAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2088"/>
        <source>Apply rate limit to transport overhead</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2081"/>
        <source>Apply rate limit to µTP protocol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2153"/>
        <source>Privacy</source>
        <translation>Sekretess</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2159"/>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2169"/>
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2172"/>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2182"/>
        <source>Look for peers on your local network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2185"/>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2197"/>
        <source>Encryption mode:</source>
        <translation>Krypteringsläge:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2205"/>
        <source>Prefer encryption</source>
        <translation>Föredra kryptering</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2210"/>
        <source>Require encryption</source>
        <translation>Kräv kryptering</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2215"/>
        <source>Disable encryption</source>
        <translation>Inaktivera kryptering</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2240"/>
        <source>Enable when using a proxy or a VPN connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2243"/>
        <source>Enable anonymous mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2293"/>
        <source>Maximum active downloads:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2313"/>
        <source>Maximum active uploads:</source>
        <translation>Högsta aktiva sändningar:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2333"/>
        <source>Maximum active torrents:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2392"/>
        <source>Do not count slow torrents in these limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2443"/>
        <source>Upload rate threshold:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2450"/>
        <source>Download rate threshold:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2483"/>
        <source> sec</source>
        <extracomment>seconds</extracomment>
        <translation>sek</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2499"/>
        <source>Torrent inactivity timer:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2512"/>
        <source>Share Ratio Limiting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2518"/>
        <source>Seed torrents until their ratio reaches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2538"/>
        <source>then</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2639"/>
        <source>Pause them</source>
        <translation>Pausa dem</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2644"/>
        <source>Remove them</source>
        <translation>Ta bort dem</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2836"/>
        <source>RSS Smart Episode Filters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2970"/>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="2995"/>
        <source>Certificate:</source>
        <translation>Certifikat:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3007"/>
        <source>Import SSL Certificate</source>
        <translation>Importera SSL-certifikat</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3032"/>
        <source>Key:</source>
        <translation>Nyckel:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3044"/>
        <source>Import SSL Key</source>
        <translation>Importera SSL-nyckel</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3066"/>
        <source>&lt;a href=https://httpd.apache.org/docs/current/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=https://httpd.apache.org/docs/current/ssl/ssl_faq.html#aboutcerts&gt;Information om certifikat&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3155"/>
        <source>Use alternative Web UI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3167"/>
        <source>Files location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3180"/>
        <source>Enable clickjacking protection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3187"/>
        <source>Enable Cross-Site Request Forgery (CSRF) protection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3206"/>
        <source>Service:</source>
        <translation>Tjänst:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3229"/>
        <source>Register</source>
        <translation>Registrera</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.ui" line="3238"/>
        <source>Domain name:</source>
        <translation>Domännamn:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="133"/>
        <source>By enabling these options, you can &lt;strong&gt;irrevocably lose&lt;/strong&gt; your .torrent files!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="135"/>
        <source>When these options are enabled, qBittorent will &lt;strong&gt;delete&lt;/strong&gt; .torrent files after they were successfully (the first option) or not (the second option) added to its download queue. This will be applied &lt;strong&gt;not only&lt;/strong&gt; to the files opened via &amp;ldquo;Add torrent&amp;rdquo; menu action but to those opened via &lt;strong&gt;file type association&lt;/strong&gt; as well</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="140"/>
        <source>If you enable the second option (&amp;ldquo;Also when addition is cancelled&amp;rdquo;) the .torrent file &lt;strong&gt;will be deleted&lt;/strong&gt; even if you press &amp;ldquo;&lt;strong&gt;Cancel&lt;/strong&gt;&amp;rdquo; in the &amp;ldquo;Add torrent&amp;rdquo; dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="198"/>
        <source>Choose Alternative UI files location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="290"/>
        <source>Supported parameters (case sensitive):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="291"/>
        <source>%N: Torrent name</source>
        <translation>%N: Torrentnamn</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="292"/>
        <source>%L: Category</source>
        <translation>%L: Kategori</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="293"/>
        <source>%G: Tags (seperated by comma)</source>
        <translation>%G: Taggar (separerade med kommatecken)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="294"/>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="295"/>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="296"/>
        <source>%D: Save path</source>
        <translation>%D: Spara sökväg</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="297"/>
        <source>%C: Number of files</source>
        <translation>%C: Antal filer</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="298"/>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z: Torrentstorlek (byte)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="299"/>
        <source>%T: Current tracker</source>
        <translation>%T: Aktuell spårare</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="300"/>
        <source>%I: Info hash</source>
        <translation>%I: Info hash</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="301"/>
        <source>Tip: Encapsulate parameter with quotation marks to avoid text being cut off at whitespace (e.g., &quot;%N&quot;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="374"/>
        <source>A torrent will be considered slow if its download and upload rates stay below these values for &quot;Torrent inactivity timer&quot; seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1527"/>
        <source>Select folder to monitor</source>
        <translation>Välj mapp för övervakning</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1534"/>
        <source>Folder is already being monitored:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1537"/>
        <source>Folder does not exist:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1540"/>
        <source>Folder is not readable:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1551"/>
        <source>Adding entry failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="426"/>
        <location filename="../gui/optionsdialog.cpp" line="429"/>
        <location filename="../gui/optionsdialog.cpp" line="1579"/>
        <location filename="../gui/optionsdialog.cpp" line="1581"/>
        <source>Choose export directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="423"/>
        <location filename="../gui/optionsdialog.cpp" line="436"/>
        <location filename="../gui/optionsdialog.cpp" line="439"/>
        <source>Choose a save directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="432"/>
        <source>Choose an IP filter file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="433"/>
        <source>All supported filters</source>
        <translation>Alla stödda filter</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1615"/>
        <source>SSL Certificate</source>
        <translation>SSL-certifikat</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1665"/>
        <source>Parsing error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1665"/>
        <source>Failed to parse the provided IP filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1667"/>
        <source>Successfully refreshed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1667"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1640"/>
        <source>Invalid key</source>
        <translation>Ogiltig nyckel</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1640"/>
        <source>This is not a valid SSL key.</source>
        <translation>Detta är inte en giltig SSL-nyckel.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1625"/>
        <source>Invalid certificate</source>
        <translation>Ogiltigt certifikat</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="98"/>
        <source>Preferences</source>
        <translation>Inställningar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1615"/>
        <source>Import SSL certificate</source>
        <translation>Importera SSL-certifikat</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1625"/>
        <source>This is not a valid SSL certificate.</source>
        <translation>Detta är inte ett giltigt SSL-certifikat.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1630"/>
        <source>Import SSL key</source>
        <translation>Importera SSL-nyckel</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1630"/>
        <source>SSL key</source>
        <translation>SSL-nyckel</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1789"/>
        <source>Time Error</source>
        <translation>Tidsfel</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1789"/>
        <source>The start time and the end time can&apos;t be the same.</source>
        <translation>Starttiden och sluttiden kan inte vara densamma.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1798"/>
        <location filename="../gui/optionsdialog.cpp" line="1802"/>
        <source>Length Error</source>
        <translation>Längdfel</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1798"/>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>Webbanvändarnamnet måste vara minst 3 tecken långt.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdialog.cpp" line="1802"/>
        <source>The Web UI password must be at least 6 characters long.</source>
        <translation>Webbanvändarlösenordet måste vara minst 6 tecken långt.</translation>
    </message>
</context>
<context>
    <name>PeerInfo</name>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="283"/>
        <source>Interested(local) and Choked(peer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="289"/>
        <source>interested(local) and unchoked(peer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="298"/>
        <source>interested(peer) and choked(local)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="304"/>
        <source>interested(peer) and unchoked(local)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="312"/>
        <source>optimistic unchoke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="319"/>
        <source>peer snubbed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="326"/>
        <source>incoming connection</source>
        <translation>inkommande anslutning</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="333"/>
        <source>not interested(local) and unchoked(peer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="340"/>
        <source>not interested(peer) and unchoked(local)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="347"/>
        <source>peer from PEX</source>
        <translation>nod från PEX</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="354"/>
        <source>peer from DHT</source>
        <translation>nod från DHT</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="361"/>
        <source>encrypted traffic</source>
        <translation>krypterad trafik</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="368"/>
        <source>encrypted handshake</source>
        <translation>krypterad handskakning</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="382"/>
        <source>peer from LSD</source>
        <translation>nod från LSD</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="72"/>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="73"/>
        <source>Port</source>
        <translation>Port</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="74"/>
        <source>Flags</source>
        <translation>Flaggor</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="75"/>
        <source>Connection</source>
        <translation>Anslutning</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="76"/>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Klient</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="77"/>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Förlopp</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="78"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Hämtningshastighet</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="79"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Sändningshastighet</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="80"/>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Hämtat</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="81"/>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Skickat</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="82"/>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don&apos;t.</comment>
        <translation>Relevans</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="83"/>
        <source>Files</source>
        <comment>i.e. files that are being downloaded right now</comment>
        <translation>Filer</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="158"/>
        <source>Column visibility</source>
        <translation>Kolumnsynlighet</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="234"/>
        <source>Add a new peer...</source>
        <translation>Lägg till en ny klient...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="242"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="281"/>
        <source>Ban peer permanently</source>
        <translation>Bannlys klient permanent</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="255"/>
        <source>Manually adding peer &apos;%1&apos;...</source>
        <translation>Lägger till nod &quot;%1&quot; manuellt...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="259"/>
        <source>The peer &apos;%1&apos; could not be added to this torrent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="291"/>
        <source>Manually banning peer &apos;%1&apos;...</source>
        <translation>Förbjuder nod &quot;%1&quot; manuellt...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="263"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="265"/>
        <source>Peer addition</source>
        <translation>Lägg till klient</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="71"/>
        <source>Country</source>
        <translation>Land</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="240"/>
        <source>Copy IP:port</source>
        <translation>Kopiera IP:port</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="263"/>
        <source>Some peers could not be added. Check the Log for details.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="265"/>
        <source>The peers were added to this torrent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="281"/>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>Är du säker på att du vill bannlysa de markerade klienterna permanent?</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="282"/>
        <source>&amp;Yes</source>
        <translation>&amp;Ja</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="282"/>
        <source>&amp;No</source>
        <translation>&amp;Nej</translation>
    </message>
</context>
<context>
    <name>PeersAdditionDialog</name>
    <message>
        <location filename="../gui/properties/peersadditiondialog.ui" line="14"/>
        <source>Add Peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.ui" line="20"/>
        <source>List of peers to add (one IP per line):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.ui" line="33"/>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="59"/>
        <source>No peer entered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="60"/>
        <source>Please type at least one peer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="70"/>
        <source>Invalid peer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondialog.cpp" line="71"/>
        <source>The peer &apos;%1&apos; is invalid.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PieceAvailabilityBar</name>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="161"/>
        <source>White: Unavailable pieces</source>
        <translation>Vit: Otillgängliga bitar</translation>
    </message>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="162"/>
        <source>Blue: Available pieces</source>
        <translation>Blå: Tillgängliga bitar</translation>
    </message>
</context>
<context>
    <name>PiecesBar</name>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="266"/>
        <source>Files in this piece:</source>
        <translation>Filer i denna bit:</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="270"/>
        <source>File in this piece</source>
        <translation>Fil i denna bit</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="272"/>
        <source>File in these pieces</source>
        <translation>Fil i dessa bitar</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="291"/>
        <source>Wait until metadata become available to see detailed information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="293"/>
        <source>Hold Shift key for detailed information</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PluginSelectDialog</name>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="17"/>
        <source>Search plugins</source>
        <translation>Sök efter insticksmoduler</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="30"/>
        <source>Installed search plugins:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="53"/>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="58"/>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="63"/>
        <source>Url</source>
        <translation>Webbadress</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="68"/>
        <location filename="../gui/search/pluginselectdialog.ui" line="134"/>
        <source>Enabled</source>
        <translation>Aktiverad</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="81"/>
        <source>Warning: Be sure to comply with your country&apos;s copyright laws when downloading torrents from any of these search engines.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="96"/>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Du kan få nya sökmotorsinsticksmoduler här: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="108"/>
        <source>Install a new one</source>
        <translation>Installera en ny</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="115"/>
        <source>Check for updates</source>
        <translation>Sök efter uppdateringar</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="122"/>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.ui" line="139"/>
        <source>Uninstall</source>
        <translation>Avinstallera</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="159"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="221"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="280"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="163"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="202"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="225"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="284"/>
        <source>No</source>
        <translation>Nej</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="208"/>
        <source>Uninstall warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="208"/>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent. Only the ones you added yourself can be uninstalled.
Those plugins were disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="210"/>
        <source>Uninstall success</source>
        <translation>Avinstallering lyckades</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="210"/>
        <source>All selected plugins were uninstalled successfully</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="323"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="422"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="436"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="468"/>
        <source>Search plugin update</source>
        <translation>Sök uppdatering för insticksmodul</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="323"/>
        <source>Plugins installed or updated: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="343"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="350"/>
        <source>New search engine plugin URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="344"/>
        <location filename="../gui/search/pluginselectdialog.cpp" line="351"/>
        <source>URL:</source>
        <translation>Webbadress:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="348"/>
        <source>Invalid link</source>
        <translation>Ogiltig länk</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="348"/>
        <source>The link doesn&apos;t seem to point to a search engine plugin.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="364"/>
        <source>Select search plugins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="365"/>
        <source>qBittorrent search plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="422"/>
        <source>All your plugins are already up to date.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="436"/>
        <source>Sorry, couldn&apos;t check for plugin updates. %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="450"/>
        <source>Search plugin install</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="451"/>
        <source>Couldn&apos;t install &quot;%1&quot; search engine plugin. %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdialog.cpp" line="469"/>
        <source>Couldn&apos;t update &quot;%1&quot; search engine plugin. %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PluginSourceDialog</name>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="14"/>
        <source>Plugin source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="27"/>
        <source>Search plugin source:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="36"/>
        <source>Local file</source>
        <translation>Lokal fil</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedialog.ui" line="43"/>
        <source>Web link</source>
        <translation>Webblänk</translation>
    </message>
</context>
<context>
    <name>PowerManagement</name>
    <message>
        <location filename="../gui/powermanagement/powermanagement.cpp" line="77"/>
        <source>qBittorrent is active</source>
        <translation>qBittorrent är aktiv</translation>
    </message>
</context>
<context>
    <name>PreviewSelectDialog</name>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="55"/>
        <source>Preview</source>
        <translation>Förhandsvisning</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="62"/>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="63"/>
        <source>Size</source>
        <translation>Storlek</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="64"/>
        <source>Progress</source>
        <translation>Förlopp</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="97"/>
        <location filename="../gui/previewselectdialog.cpp" line="142"/>
        <source>Preview impossible</source>
        <translation>Förhandsgranskning omöjlig</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="97"/>
        <location filename="../gui/previewselectdialog.cpp" line="142"/>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>Tyvärr, vi kan inte förhandsgranska den här filen</translation>
    </message>
</context>
<context>
    <name>Private::FileLineEdit</name>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="305"/>
        <source>&apos;%1&apos; does not exist</source>
        <translation>&apos;%1&apos; finns inte</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="307"/>
        <source>&apos;%1&apos; does not point to a directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="309"/>
        <source>&apos;%1&apos; does not point to a file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="311"/>
        <source>Does not have read permission in &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="313"/>
        <source>Does not have write permission in &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="118"/>
        <source>Not downloaded</source>
        <translation>Inte hämtad</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="127"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="189"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="136"/>
        <source>N/A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="188"/>
        <source>Do not download</source>
        <comment>Do not download (priority)</comment>
        <translation>Hämta inte</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="121"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="190"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Hög</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="115"/>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Blandat</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="124"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="191"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Högsta</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="50"/>
        <source>General</source>
        <translation>Allmänt</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="59"/>
        <source>Trackers</source>
        <translation>Bevakare</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="68"/>
        <source>Peers</source>
        <translation>Klienter</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="77"/>
        <source>HTTP Sources</source>
        <translation>HTTP-källor</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="86"/>
        <source>Content</source>
        <translation>Innehåll</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="97"/>
        <source>Speed</source>
        <translation>Hastighet</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="330"/>
        <source>Downloaded:</source>
        <translation>Hämtat:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="107"/>
        <source>Availability:</source>
        <translation>Tillgänglighet:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="78"/>
        <source>Progress:</source>
        <translation>Förlopp:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="154"/>
        <source>Transfer</source>
        <translation>Överför</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="546"/>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Tid aktiv:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="575"/>
        <source>ETA:</source>
        <translation>Färdig om:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="504"/>
        <source>Uploaded:</source>
        <translation>Skickat:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="433"/>
        <source>Seeds:</source>
        <translation>Distribueringar:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="449"/>
        <source>Download Speed:</source>
        <translation>Hämtningshastighet:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="185"/>
        <source>Upload Speed:</source>
        <translation>Sändningshastighet:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="214"/>
        <source>Peers:</source>
        <translation>Klienter:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="272"/>
        <source>Download Limit:</source>
        <translation>Hämtningsgräns:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="346"/>
        <source>Upload Limit:</source>
        <translation>Sändningsgräns:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="591"/>
        <source>Wasted:</source>
        <translation>Förkastat:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="230"/>
        <source>Connections:</source>
        <translation>Anslutningar:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="604"/>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="863"/>
        <source>Comment:</source>
        <translation>Kommentar:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1023"/>
        <source>Select All</source>
        <translation>Markera allt</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1030"/>
        <source>Select None</source>
        <translation>Markera ingen</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1106"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1101"/>
        <source>High</source>
        <translation>Hög</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="288"/>
        <source>Share Ratio:</source>
        <translation>Utdelningsförhållande:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="404"/>
        <source>Reannounce In:</source>
        <translation>Annonsering igen om:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="362"/>
        <source>Last Seen Complete:</source>
        <translation>Sågs senast fullständig</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="622"/>
        <source>Total Size:</source>
        <translation>Storlek totalt:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="651"/>
        <source>Pieces:</source>
        <translation>Delar:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="680"/>
        <source>Created By:</source>
        <translation>Skapades av:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="709"/>
        <source>Added On:</source>
        <translation>Lades till:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="738"/>
        <source>Completed On:</source>
        <translation>Färdigställdes:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="767"/>
        <source>Created On:</source>
        <translation>Skapades den:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="796"/>
        <source>Torrent Hash:</source>
        <translation>Torrent-hash:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="828"/>
        <source>Save Path:</source>
        <translation>Sökväg att spara i:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1096"/>
        <source>Maximum</source>
        <translation>Högsta</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1088"/>
        <location filename="../gui/properties/propertieswidget.ui" line="1091"/>
        <source>Do not download</source>
        <translation>Hämta inte</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="456"/>
        <source>Never</source>
        <translation>Aldrig</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="463"/>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (har %3)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="408"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="411"/>
        <source>%1 (%2 this session)</source>
        <translation>%1 (%2 denna session)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="420"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation type="unfinished">%1 (distribuerad för %2)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="427"/>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (%2 max)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="440"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="444"/>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (%2 totalt)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="448"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="452"/>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="596"/>
        <source>Open</source>
        <translation>Öppna</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="597"/>
        <source>Open Containing Folder</source>
        <translation>Öppna innehållande katalog</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="598"/>
        <source>Rename...</source>
        <translation>Byt namn...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="603"/>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="651"/>
        <source>New Web seed</source>
        <translation>Ny webbdistribution</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="657"/>
        <source>Remove Web seed</source>
        <translation>Ta bort webbdistribution</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="659"/>
        <source>Copy Web seed URL</source>
        <translation>Kopiera webbdistributions URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="660"/>
        <source>Edit Web seed URL</source>
        <translation>Ändra webbdistributions URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="689"/>
        <source>New name:</source>
        <translation>Nytt namn:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="723"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="761"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Detta namn används redan i denna mapp. Använd ett annat namn.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="760"/>
        <source>The folder could not be renamed</source>
        <translation>Det gick inte att byta namn på mappen</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="864"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="91"/>
        <source>Filter files...</source>
        <translation>Filtrera filer...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="689"/>
        <source>Renaming</source>
        <translation>Byter namn</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="694"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="722"/>
        <source>Rename error</source>
        <translation type="unfinished">Fel vid namnbyte</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="695"/>
        <source>The name is empty or contains forbidden characters, please choose a different one.</source>
        <translation type="unfinished">Namnet är tomt eller innehåller förbjudna tecken, vänligen välj ett annat filnamn.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="807"/>
        <source>New URL seed</source>
        <comment>New HTTP source</comment>
        <translation>Ny URL-distribution</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="808"/>
        <source>New URL seed:</source>
        <translation>Ny URL-distribution:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="814"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="865"/>
        <source>This URL seed is already in the list.</source>
        <translation>Den här URL-distributionen finns redan i listan.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="858"/>
        <source>Web seed editing</source>
        <translation>Webbdistributionredigering</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="859"/>
        <source>Web seed URL:</source>
        <translation>URL för webbdistribution:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../app/main.cpp" line="133"/>
        <source>%1 is an unknown command line parameter.</source>
        <comment>--random-parameter is an unknown command line parameter.</comment>
        <translation>%1 är en okänd parameter</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="143"/>
        <location filename="../app/main.cpp" line="152"/>
        <source>%1 must be the single command line parameter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="175"/>
        <source>You cannot use %1: qBittorrent is already running for this user.</source>
        <translation>Du kan inte använda %1: qBittorrent körs redan för denna användare.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="519"/>
        <source>Usage:</source>
        <translation>Användning:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="522"/>
        <source>Options:</source>
        <translation>Alternativ:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="156"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--webui-port&apos; must follow syntax &apos;--webui-port=value&apos;</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="202"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--webui-port&apos; must follow syntax &apos;--webui-port=&lt;value&gt;&apos;</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="216"/>
        <source>Expected integer number in environment variable &apos;%1&apos;, but got &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="269"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--add-paused&apos; must follow syntax &apos;--add-paused=&lt;true|false&gt;&apos;</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="293"/>
        <source>Expected %1 in environment variable &apos;%2&apos;, but got &apos;%3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="527"/>
        <source>port</source>
        <translation>port</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="418"/>
        <source>%1 must specify a valid port (1 to 65535).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="524"/>
        <source>Display program version and exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="526"/>
        <source>Display this help message and exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="528"/>
        <source>Change the Web UI port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="531"/>
        <source>Disable splash screen</source>
        <translation>Inaktivera startbilden</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="533"/>
        <source>Run in daemon-mode (background)</source>
        <translation>Kör i demonläge (i bakgrunden)</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="536"/>
        <source>dir</source>
        <extracomment>Use appropriate short form or abbreviation of &quot;directory&quot;</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="537"/>
        <source>Store configuration files in &lt;dir&gt;</source>
        <translation>Spara konfigurationsfiler i &lt;dir&gt;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="538"/>
        <location filename="../app/cmdoptions.cpp" line="554"/>
        <source>name</source>
        <translation>namn</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="539"/>
        <source>Store configuration files in directories qBittorrent_&lt;name&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="541"/>
        <source>Hack into libtorrent fastresume files and make file paths relative to the profile directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="546"/>
        <source>files or URLs</source>
        <translation>filer eller webbadresser</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="547"/>
        <source>Download the torrents passed by the user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="561"/>
        <source>Specify whether the &quot;Add New Torrent&quot; dialog opens when adding a torrent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="550"/>
        <source>Options when adding new torrents:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="544"/>
        <source>Shortcut for %1</source>
        <comment>Shortcut for --profile=&lt;exe dir&gt;/profile --relative-fastresume</comment>
        <translation>Genväg för %1</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="551"/>
        <source>path</source>
        <translation>sökväg</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="551"/>
        <source>Torrent save path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="552"/>
        <source>Add torrents as started or paused</source>
        <translation>Lägg till torrenter som startade eller pausade</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="553"/>
        <source>Skip hash check</source>
        <translation>Hoppa över hash kontroll</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="555"/>
        <source>Assign torrents to category. If the category doesn&apos;t exist, it will be created.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="557"/>
        <source>Download files in sequential order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="559"/>
        <source>Download first and last pieces first</source>
        <translation type="unfinished">Hämta första och sista bitarna först</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="565"/>
        <source>Option values may be supplied via environment variables. For option named &apos;parameter-name&apos;, environment variable name is &apos;QBT_PARAMETER_NAME&apos; (in upper case, &apos;-&apos; replaced with &apos;_&apos;). To pass flag values, set the variable to &apos;1&apos; or &apos;TRUE&apos;. For example, to disable the splash screen: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="570"/>
        <source>Command line parameters take precedence over environment variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="581"/>
        <source>Help</source>
        <translation>Hjälp</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="334"/>
        <source>Run application with -h option to read about command line parameters.</source>
        <translation>Kör applikationen med -h optionen för att läsa om kommando parametrar.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="336"/>
        <source>Bad command line</source>
        <translation>Ogiltig kommandorad</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="342"/>
        <source>Bad command line: </source>
        <translation>Ogiltig kommandorad:</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="356"/>
        <source>Legal Notice</source>
        <translation>Juridisk information</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="357"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="358"/>
        <source>No further notices will be issued.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="370"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>qBittorrent är ett fildelarprogram. När du kör en torrent så kommer dess data att göras tillgängligt för andra genom sändning. Och så klart, allt innehåll som du delar ut är fullständigt på ditt ansvar.

Detta meddelande kommer inte att visas igen.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="359"/>
        <source>Press %1 key to accept and continue...</source>
        <translation>Tryck på %1-tangenten för att godkänna och fortsätta...</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="371"/>
        <source>Legal notice</source>
        <translation>Juridisk information</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="372"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="373"/>
        <source>I Agree</source>
        <translation>Jag godkänner</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="64"/>
        <location filename="../app/upgrade.h" line="78"/>
        <source>Upgrade</source>
        <translation>Uppgradera</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="68"/>
        <source>You updated from an older version that saved things differently. You must migrate to the new saving system. You will not be able to use an older version than v3.3.0 again. Continue? [y/n]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="77"/>
        <source>You updated from an older version that saved things differently. You must migrate to the new saving system. If you continue, you will not be able to use an older version than v3.3.0 again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="210"/>
        <source>Couldn&apos;t migrate torrent with hash: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="213"/>
        <source>Couldn&apos;t migrate torrent. Invalid fastresume file name: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="240"/>
        <source>Detected unclean program exit. Using fallback file to restore settings: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="307"/>
        <source>An access error occurred while trying to write the configuration file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="310"/>
        <source>A format error occurred while trying to write the configuration file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="313"/>
        <source>An unknown error occurred while trying to write the configuration file.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RSS::AutoDownloader</name>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="80"/>
        <location filename="../base/rss/rss_autodownloader.cpp" line="87"/>
        <source>Invalid data format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="122"/>
        <source>Couldn&apos;t save RSS AutoDownloader data in %1. Error: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="276"/>
        <source>Invalid data format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="407"/>
        <source>Couldn&apos;t read RSS AutoDownloader rules from %1. Error: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_autodownloader.cpp" line="419"/>
        <source>Couldn&apos;t load RSS AutoDownloader rules. Reason: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RSS::Feed</name>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="208"/>
        <source>Failed to download RSS feed at &apos;%1&apos;. Reason: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="251"/>
        <source>RSS feed at &apos;%1&apos; updated. Added %2 new articles.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="256"/>
        <source>Failed to parse RSS feed at &apos;%1&apos;. Reason: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="278"/>
        <source>Couldn&apos;t read RSS Session data from %1. Error: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="289"/>
        <source>Couldn&apos;t parse RSS Session data. Error: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="295"/>
        <source>Couldn&apos;t load RSS Session data. Invalid data format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="304"/>
        <source>Couldn&apos;t load RSS article &apos;%1#%2&apos;. Invalid data format.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RSS::Private::Parser</name>
    <message>
        <location filename="../base/rss/private/rss_parser.cpp" line="578"/>
        <source>Invalid RSS feed.</source>
        <translation>Ogiltigt RSS-flöde.</translation>
    </message>
    <message>
        <location filename="../base/rss/private/rss_parser.cpp" line="581"/>
        <source>%1 (line: %2, column: %3, offset: %4).</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RSS::Session</name>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="161"/>
        <source>RSS feed with given URL already exists: %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="180"/>
        <source>Cannot move root folder.</source>
        <translation>Det går inte att flytta root-mapp.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="187"/>
        <location filename="../base/rss/rss_session.cpp" line="225"/>
        <source>Item doesn&apos;t exist: %1.</source>
        <translation>Artikeln existerar inte: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="218"/>
        <source>Cannot delete root folder.</source>
        <translation>Kan inte radera root-mapp.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="380"/>
        <source>Incorrect RSS Item path: %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="386"/>
        <source>RSS item with given path already exists: %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="394"/>
        <source>Parent folder doesn&apos;t exist: %1.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RSSWidget</name>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="17"/>
        <source>Search</source>
        <translation>Sök</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="31"/>
        <source>Fetching of RSS feeds is disabled now! You can enable it in application settings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="43"/>
        <source>New subscription</source>
        <translation>Ny prenumeration</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="50"/>
        <location filename="../gui/rss/rsswidget.ui" line="174"/>
        <location filename="../gui/rss/rsswidget.ui" line="177"/>
        <source>Mark items read</source>
        <translation>Märk som läst</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="57"/>
        <source>Refresh RSS streams</source>
        <translation>Uppdatera RSS-flöden</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="60"/>
        <source>Update all</source>
        <translation>Uppdatera alla</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="80"/>
        <source>RSS Downloader...</source>
        <translation>RSS-hämtare...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="108"/>
        <source>Torrents: (double-click to download)</source>
        <translation>Torrenter: (dubbelklicka för att hämta)</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="137"/>
        <location filename="../gui/rss/rsswidget.ui" line="140"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="145"/>
        <source>Rename...</source>
        <translation>Byt namn...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="148"/>
        <source>Rename</source>
        <translation>Byt namn</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="153"/>
        <location filename="../gui/rss/rsswidget.ui" line="156"/>
        <source>Update</source>
        <translation>Uppdatera</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="161"/>
        <source>New subscription...</source>
        <translation>Ny prenumeration...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="166"/>
        <location filename="../gui/rss/rsswidget.ui" line="169"/>
        <source>Update all feeds</source>
        <translation>Uppdatera alla flöden</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="182"/>
        <source>Download torrent</source>
        <translation>Hämta torrent</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="187"/>
        <source>Open news URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="192"/>
        <source>Copy feed URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="197"/>
        <source>New folder...</source>
        <translation>Ny mapp...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="214"/>
        <source>Please choose a folder name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="214"/>
        <source>Folder name:</source>
        <translation>Mappnamn</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="215"/>
        <source>New folder</source>
        <translation>Ny mapp</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="255"/>
        <source>Please type a RSS feed URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="255"/>
        <source>Feed URL:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="296"/>
        <source>Deletion confirmation</source>
        <translation>Borttagningsbekräftelse</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="296"/>
        <source>Are you sure you want to delete the selected RSS feeds?</source>
        <translation>Är du säker på att du vill ta bort de valda RSS-flödena?</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="385"/>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Välj ett nytt namn för detta RSS-flöde</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="385"/>
        <source>New feed name:</source>
        <translation>Nytt namn på flöde:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="392"/>
        <source>Rename failed</source>
        <translation>Byt namn misslyckades</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="455"/>
        <source>Date: </source>
        <translation>Datum:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="457"/>
        <source>Author: </source>
        <translation>Författare: </translation>
    </message>
</context>
<context>
    <name>ScanFoldersDelegate</name>
    <message>
        <location filename="../gui/scanfoldersdelegate.cpp" line="99"/>
        <source>Select save location</source>
        <translation>Välj spara plats</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="149"/>
        <source>Monitored Folder</source>
        <translation>Övervakad mapp</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="152"/>
        <source>Override Save Location</source>
        <translation>Åsidosätt spara plats</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="393"/>
        <source>Monitored folder</source>
        <translation>Övervakad mapp</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="395"/>
        <source>Default save location</source>
        <translation>Standard spara plats</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="397"/>
        <source>Browse...</source>
        <translation>Bläddra...</translation>
    </message>
</context>
<context>
    <name>SearchJobWidget</name>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="22"/>
        <source>Results(xxx)</source>
        <translation>Resultat(xxx)</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="45"/>
        <source>Search in:</source>
        <translation>Sök i:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="55"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Some search engines search in torrent description and in torrent file names too. Whether such results will be shown in the list below is controlled by this mode.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Everywhere &lt;/span&gt;disables filtering and shows everything returned by the search engines.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrent names only&lt;/span&gt; shows only torrents whose names match the search query.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="84"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed number of seeders&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="87"/>
        <source>Seeds:</source>
        <translation type="unfinished">Distribueringar:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="94"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="116"/>
        <location filename="../gui/search/searchjobwidget.ui" line="204"/>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="123"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="126"/>
        <location filename="../gui/search/searchjobwidget.ui" line="216"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="167"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed size of a torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="170"/>
        <source>Size:</source>
        <translation>Storlek:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="179"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.ui" line="213"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="78"/>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="79"/>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Storlek</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="80"/>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Distributörer</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="81"/>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="82"/>
        <source>Search engine</source>
        <translation>Sökmotor</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="133"/>
        <source>Filter search results...</source>
        <translation>Filtrera sökresultat...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="291"/>
        <source>Results (showing &lt;i&gt;%1&lt;/i&gt; out of &lt;i&gt;%2&lt;/i&gt;):</source>
        <comment>i.e: Search results</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="340"/>
        <source>Torrent names only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="341"/>
        <source>Everywhere</source>
        <translation>Överallt</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="362"/>
        <source>Use regular expressions</source>
        <translation type="unfinished">Använd reguljära uttryck</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="377"/>
        <source>Searching...</source>
        <translation>Söker...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="379"/>
        <source>Search has finished</source>
        <translation type="unfinished">Sökningen är färdig</translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="381"/>
        <source>Search aborted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="383"/>
        <source>An error occurred during search...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="385"/>
        <source>Search returned no results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchjobwidget.cpp" line="409"/>
        <source>Column visibility</source>
        <translation type="unfinished">Kolumnsynlighet</translation>
    </message>
</context>
<context>
    <name>SearchPluginManager</name>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="210"/>
        <source>Unknown search engine plugin file format.</source>
        <translation>Okänd sökmotor insticksmodulsfilformat.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="224"/>
        <source>A more recent version of this plugin is already installed.</source>
        <translation>En senare version av den här insticksmodulen är redan installerad.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="251"/>
        <location filename="../base/search/searchpluginmanager.cpp" line="254"/>
        <source>Plugin is not supported.</source>
        <translation>Insticksmodul stöds inte.</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="323"/>
        <source>All categories</source>
        <translation>Alla kategorier</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="324"/>
        <source>Movies</source>
        <translation>Filmer</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="325"/>
        <source>TV shows</source>
        <translation>Tv program</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="326"/>
        <source>Music</source>
        <translation>Musik</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="327"/>
        <source>Games</source>
        <translation>Spel</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="328"/>
        <source>Anime</source>
        <translation>Animerat</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="329"/>
        <source>Software</source>
        <translation>Mjukvara</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="330"/>
        <source>Pictures</source>
        <translation>Bilder</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="331"/>
        <source>Books</source>
        <translation>Böcker</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="370"/>
        <source>Update server is temporarily unavailable. %1</source>
        <translation>Uppdateringsserveren är tillfälligt otillgänglig. %1</translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="388"/>
        <location filename="../base/search/searchpluginmanager.cpp" line="390"/>
        <source>Failed to download the plugin file. %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="525"/>
        <source>An incorrect update info received.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/search/searchpluginmanager.cpp" line="560"/>
        <source>Search plugin &apos;%1&apos; contains invalid version string (&apos;%2&apos;)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="14"/>
        <location filename="../gui/search/searchwidget.ui" line="51"/>
        <location filename="../gui/search/searchwidget.cpp" line="287"/>
        <location filename="../gui/search/searchwidget.cpp" line="307"/>
        <location filename="../gui/search/searchwidget.cpp" line="378"/>
        <location filename="../gui/search/searchwidget.cpp" line="386"/>
        <source>Search</source>
        <translation>Sök</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="79"/>
        <source>There aren&apos;t any search plugins installed.
Click the &quot;Search plugins...&quot; button at the bottom right of the window to install some.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="122"/>
        <source>Download</source>
        <translation>Hämta</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="132"/>
        <source>Go to description page</source>
        <translation>Gå till beskrivningssidan</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="142"/>
        <source>Copy description page URL</source>
        <translation>Kopiera beskrivningssidans URL</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="162"/>
        <source>Search plugins...</source>
        <translation>Sök insticksmodul...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="102"/>
        <source>A phrase to search for.</source>
        <translation>En fras att söka efter.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="103"/>
        <source>Spaces in a search term may be protected by double quotes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="105"/>
        <source>Example:</source>
        <comment>Search phrase example</comment>
        <translation>Exempel:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="107"/>
        <source>&lt;b&gt;foo bar&lt;/b&gt;: search for &lt;b&gt;foo&lt;/b&gt; and &lt;b&gt;bar&lt;/b&gt;</source>
        <comment>Search phrase example, illustrates quotes usage, a pair of space delimited words, individal words are highlighted</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="111"/>
        <source>&lt;b&gt;&amp;quot;foo bar&amp;quot;&lt;/b&gt;: search for &lt;b&gt;foo bar&lt;/b&gt;</source>
        <comment>Search phrase example, illustrates quotes usage, double quotedpair of space delimited words, the whole pair is highlighted</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="187"/>
        <source>All plugins</source>
        <translation>Alla insticksmoduler</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="186"/>
        <source>Only enabled</source>
        <translation>Endast aktiverade</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="188"/>
        <source>Select...</source>
        <translation>Välj...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="300"/>
        <location filename="../gui/search/searchwidget.cpp" line="372"/>
        <location filename="../gui/search/searchwidget.cpp" line="374"/>
        <source>Search Engine</source>
        <translation>Sökmotor</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="300"/>
        <source>Please install Python to use the Search Engine.</source>
        <translation>Installera Python för att använda sökmotorn.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="317"/>
        <source>Empty search pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="317"/>
        <source>Please type a search pattern first</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="350"/>
        <source>Stop</source>
        <translation>Stoppa</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="374"/>
        <source>Search has finished</source>
        <translation>Sökningen är färdig</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="372"/>
        <source>Search has failed</source>
        <translation>Sökningen misslyckades</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDialog</name>
    <message>
        <location filename="../gui/shutdownconfirmdialog.ui" line="64"/>
        <source>Don&apos;t show again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="113"/>
        <source>qBittorrent will now exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="114"/>
        <source>E&amp;xit Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="115"/>
        <source>Exit confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="118"/>
        <source>The computer is going to shutdown.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="119"/>
        <source>&amp;Shutdown Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="120"/>
        <source>Shutdown confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="123"/>
        <source>The computer is going to enter suspend mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="124"/>
        <source>&amp;Suspend Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="125"/>
        <source>Suspend confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="128"/>
        <source>The computer is going to enter hibernation mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="129"/>
        <source>&amp;Hibernate Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="130"/>
        <source>Hibernate confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdialog.cpp" line="140"/>
        <source>You can cancel the action within %1 seconds.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <location filename="../gui/speedlimitdialog.cpp" line="85"/>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>SpeedPlotView</name>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="53"/>
        <source>Total Upload</source>
        <translation>Skickat totalt</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="54"/>
        <source>Total Download</source>
        <translation>Hämtat totalt</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="58"/>
        <source>Payload Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="59"/>
        <source>Payload Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="63"/>
        <source>Overhead Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="64"/>
        <source>Overhead Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="68"/>
        <source>DHT Upload</source>
        <translation>DHT skickat</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="69"/>
        <source>DHT Download</source>
        <translation>DHT hämtat</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="73"/>
        <source>Tracker Upload</source>
        <translation>Sändning för bevakare</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="74"/>
        <source>Tracker Download</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpeedWidget</name>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="68"/>
        <source>Period:</source>
        <translation>Period:</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="71"/>
        <source>1 Minute</source>
        <translation>1 minut</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="72"/>
        <source>5 Minutes</source>
        <translation>5 minuter</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="73"/>
        <source>30 Minutes</source>
        <translation>30 minuter</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="74"/>
        <source>6 Hours</source>
        <translation>6 Timmar</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="106"/>
        <source>Select Graphs</source>
        <translation>Välj grafer</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="80"/>
        <source>Total Upload</source>
        <translation>Skickat totalt</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="81"/>
        <source>Total Download</source>
        <translation>Hämtat totalt</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="82"/>
        <source>Payload Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="83"/>
        <source>Payload Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="84"/>
        <source>Overhead Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="85"/>
        <source>Overhead Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="86"/>
        <source>DHT Upload</source>
        <translation>DHT skickat</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="87"/>
        <source>DHT Download</source>
        <translation>DHT hämtat</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="88"/>
        <source>Tracker Upload</source>
        <translation>Sändning för bevakare</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="89"/>
        <source>Tracker Download</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StacktraceDialog</name>
    <message>
        <location filename="../app/stacktracedialog.ui" line="14"/>
        <source>Crash info</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <location filename="../gui/statsdialog.ui" line="14"/>
        <source>Statistics</source>
        <translation>Statistik</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="20"/>
        <source>User statistics</source>
        <translation>Användarstatistik</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="99"/>
        <source>Cache statistics</source>
        <translation>Cache Statistik</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="105"/>
        <source>Read cache hits:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="184"/>
        <source>Average time in queue:</source>
        <translation>Genomsnittlig tid i kö:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="33"/>
        <source>Connected peers:</source>
        <translation>Anslutna noder:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="40"/>
        <source>All-time share ratio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="54"/>
        <source>All-time download:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="75"/>
        <source>Session waste:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="82"/>
        <source>All-time upload:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="126"/>
        <source>Total buffer size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="136"/>
        <source>Performance statistics</source>
        <translation>Prestandastatistik</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="170"/>
        <source>Queued I/O jobs:</source>
        <translation>Köade I/O-uppgifter: </translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="177"/>
        <source>Write cache overload:</source>
        <translation>Skrivcachen överbelastad: </translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="191"/>
        <source>Read cache overload:</source>
        <translation>Läscache överbelastad: </translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="198"/>
        <source>Total queued size:</source>
        <translation>Köstorlek totalt: </translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.cpp" line="105"/>
        <source>%1 ms</source>
        <comment>18 milliseconds</comment>
        <translation>%1 ms</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <location filename="../gui/statusbar.cpp" line="68"/>
        <location filename="../gui/statusbar.cpp" line="188"/>
        <source>Connection status:</source>
        <translation>Anslutningsstatus:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="69"/>
        <location filename="../gui/statusbar.cpp" line="188"/>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>Inga direktanslutningar. Detta kan betyda problem med nätverkskonfigurationen.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="90"/>
        <location filename="../gui/statusbar.cpp" line="197"/>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 noder</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="161"/>
        <source>qBittorrent needs to be restarted!</source>
        <translation>qBittorrent behöver startas om!</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="178"/>
        <location filename="../gui/statusbar.cpp" line="184"/>
        <source>Connection Status:</source>
        <translation>Anslutningsstatus:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="178"/>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Frånkopplad. Detta betyder oftast att qBittorrent misslyckades med att lyssna på den valda porten för inkommande anslutningar.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="184"/>
        <source>Online</source>
        <translation>Ansluten</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="239"/>
        <source>Click to switch to alternative speed limits</source>
        <translation>Klicka för att växla till alternativa hastighetsgränser</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="234"/>
        <source>Click to switch to regular speed limits</source>
        <translation>Klicka för att växla till vanliga hastighetsgränser</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="251"/>
        <source>Global Download Speed Limit</source>
        <translation>Allmän hastighetsgräns för hämtning</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="265"/>
        <source>Global Upload Speed Limit</source>
        <translation>Allmän hastighetsgräns för sändning</translation>
    </message>
</context>
<context>
    <name>StatusFilterWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="134"/>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>Alla (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="137"/>
        <source>Downloading (0)</source>
        <translation>Hämtar (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="140"/>
        <source>Seeding (0)</source>
        <translation>Distributerar (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="143"/>
        <source>Completed (0)</source>
        <translation>Färdig (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="146"/>
        <source>Resumed (0)</source>
        <translation>Återupptagna (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="149"/>
        <source>Paused (0)</source>
        <translation>Pausade (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="152"/>
        <source>Active (0)</source>
        <translation>Aktiva (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="155"/>
        <source>Inactive (0)</source>
        <translation>Inaktiva (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="158"/>
        <source>Errored (0)</source>
        <translation>Med fel (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="175"/>
        <source>All (%1)</source>
        <translation>Alla (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="176"/>
        <source>Downloading (%1)</source>
        <translation>Hämtar (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="177"/>
        <source>Seeding (%1)</source>
        <translation>Distributerar (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="178"/>
        <source>Completed (%1)</source>
        <translation>Färdiga (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="179"/>
        <source>Paused (%1)</source>
        <translation>Pausade (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="180"/>
        <source>Resumed (%1)</source>
        <translation>Återupptagna (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="181"/>
        <source>Active (%1)</source>
        <translation>Aktiva (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="182"/>
        <source>Inactive (%1)</source>
        <translation>Inaktiva (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="183"/>
        <source>Errored (%1)</source>
        <translation>Med fel (%1)</translation>
    </message>
</context>
<context>
    <name>TagFilterModel</name>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="146"/>
        <source>Tags</source>
        <translation>Taggar</translation>
    </message>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="257"/>
        <source>All</source>
        <translation>Alla</translation>
    </message>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="259"/>
        <source>Untagged</source>
        <translation>Otaggade</translation>
    </message>
</context>
<context>
    <name>TagFilterWidget</name>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="112"/>
        <source>Add tag...</source>
        <translation>Lägg till tagg...</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="119"/>
        <source>Remove tag</source>
        <translation>Ta bort tagg</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="125"/>
        <source>Remove unused tags</source>
        <translation>Ta bort oanvända taggar</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="132"/>
        <source>Resume torrents</source>
        <translation>Återuppta torrenter</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="138"/>
        <source>Pause torrents</source>
        <translation>Pausa torrenter</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="144"/>
        <source>Delete torrents</source>
        <translation>Ta bort torrenter</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="187"/>
        <source>New Tag</source>
        <translation>Ny tagg</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="187"/>
        <source>Tag:</source>
        <translation>Tagg:</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="191"/>
        <source>Invalid tag name</source>
        <translation>Ogiltigt taggnamn</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="192"/>
        <source>Tag name &apos;%1&apos; is invalid</source>
        <translation>Taggnamn &apos;%1&apos; är ogiltigt</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="207"/>
        <source>Tag exists</source>
        <translation>Tagg finns</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="207"/>
        <source>Tag name already exists.</source>
        <translation>Taggnamn finns redan.</translation>
    </message>
</context>
<context>
    <name>TorrentCategoryDialog</name>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="14"/>
        <source>Torrent Category Properties</source>
        <translation>Torrent-kategori egenskaper</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="35"/>
        <source>Name:</source>
        <translation>Namn:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="45"/>
        <source>Save path:</source>
        <translation>Spara sökväg:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="43"/>
        <source>Choose save path</source>
        <translation>Välj spara sökväg</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="58"/>
        <source>New Category</source>
        <translation>Ny kategori</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="67"/>
        <source>Invalid category name</source>
        <translation>Ogiltigt kategorinamn</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="68"/>
        <source>Category name cannot contain &apos;\&apos;.
Category name cannot start/end with &apos;/&apos;.
Category name cannot contain &apos;//&apos; sequence.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="74"/>
        <source>Category creation error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="75"/>
        <source>Category with the given name already exists.
Please choose a different name and try again.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Size</source>
        <translation>Storlek</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Progress</source>
        <translation>Förlopp</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Download Priority</source>
        <translation>Hämtningsprioritet</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Remaining</source>
        <translation>Återstår</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Availability</source>
        <translation>Tillgänglighet</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDialog</name>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="17"/>
        <source>Torrent Creator</source>
        <translation>Torrent-skapare</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="23"/>
        <source>Select file/folder to share</source>
        <translation>Välj fil/mapp att dela</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="31"/>
        <source>Path:</source>
        <translation>Sökväg:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="58"/>
        <source>[Drag and drop area]</source>
        <translation>[Dra och släpp område]</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="68"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="111"/>
        <source>Select file</source>
        <translation>Välj fil</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="75"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="104"/>
        <source>Select folder</source>
        <translation>Välj mapp</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="87"/>
        <source>Settings</source>
        <translation>Inställningar</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="95"/>
        <source>Piece size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="109"/>
        <source>Auto</source>
        <translation>Automatisk</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="114"/>
        <source>16 KiB</source>
        <translation>16 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="119"/>
        <source>32 KiB</source>
        <translation>32 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="124"/>
        <source>64 KiB</source>
        <translation>64 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="129"/>
        <source>128 KiB</source>
        <translation>128 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="134"/>
        <source>256 KiB</source>
        <translation>256 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="139"/>
        <source>512 KiB</source>
        <translation>512 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="144"/>
        <source>1 MiB</source>
        <translation>1 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="149"/>
        <source>2 MiB</source>
        <translation>2 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="154"/>
        <source>4 MiB</source>
        <translation>4 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="159"/>
        <source>8 MiB</source>
        <translation>8 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="164"/>
        <source>16 MiB</source>
        <translation>16 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="169"/>
        <source>32 MiB</source>
        <translation>32 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="177"/>
        <source>Calculate number of pieces:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="206"/>
        <source>Private torrent (Won&apos;t distribute on DHT network)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="213"/>
        <source>Start seeding immediately</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="223"/>
        <source>Ignore share ratio limits for this torrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="230"/>
        <source>Optimize alignment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="243"/>
        <source>Fields</source>
        <translation>Fält</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="249"/>
        <source>You can separate tracker tiers / groups with an empty line.</source>
        <comment>A tracker tier is a group of trackers, consisting of a main tracker and its mirrors.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="259"/>
        <source>Web seed URLs:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="280"/>
        <source>Tracker URLs:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="287"/>
        <source>Comments:</source>
        <translation>Kommentarer:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="294"/>
        <source>Source:</source>
        <translation>Källa:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.ui" line="309"/>
        <source>Progress:</source>
        <translation>Förlopp:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="70"/>
        <source>Create Torrent</source>
        <translation>Skapa torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="148"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="182"/>
        <location filename="../gui/torrentcreatordialog.cpp" line="194"/>
        <source>Torrent creation failed</source>
        <translation>Torrent skapande misslyckades</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="148"/>
        <source>Reason: Path to file/folder is not readable.</source>
        <translation>Orsak: Sökväg till fil/mapp är inte läsbar.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="155"/>
        <source>Select where to save the new torrent</source>
        <translation>Välj var du vill spara den nya torrenten</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="155"/>
        <source>Torrent Files (*.torrent)</source>
        <translation>Torrentfiler (*.torrent)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="182"/>
        <source>Reason: %1</source>
        <translation>Orsak: %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="194"/>
        <source>Reason: Created torrent is invalid. It won&apos;t be added to download list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="205"/>
        <source>Torrent creator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordialog.cpp" line="206"/>
        <source>Torrent created:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TorrentInfo</name>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="111"/>
        <source>File size exceeds max limit %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="121"/>
        <source>Torrent file read error: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrentinfo.cpp" line="126"/>
        <source>Torrent file read error: size mismatch</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TorrentsController</name>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="315"/>
        <source>Not contacted yet</source>
        <translation>Inte kontaktade ännu</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="317"/>
        <source>Updating...</source>
        <translation>Uppdaterar...</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="319"/>
        <source>Working</source>
        <translation>Arbetar</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="321"/>
        <source>Not working</source>
        <translation>Arbetar inte</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="511"/>
        <source>Error: &apos;%1&apos; is not a valid torrent file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="694"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="705"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="716"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="727"/>
        <source>Torrent queueing must be enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="741"/>
        <source>Save path cannot be empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="828"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="845"/>
        <source>Category cannot be empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="834"/>
        <source>Unable to create category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="848"/>
        <source>Unable to edit category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save path is empty</source>
        <translation type="vanished">Spara sökväg är tom</translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="745"/>
        <source>Cannot make save path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="749"/>
        <source>Cannot write to directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="753"/>
        <source>WebUI Set location: moving &quot;%1&quot;, from &quot;%2&quot; to &quot;%3&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="767"/>
        <source>Incorrect torrent name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/api/torrentscontroller.cpp" line="816"/>
        <location filename="../webui/api/torrentscontroller.cpp" line="831"/>
        <source>Incorrect category name</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="203"/>
        <source>All (0)</source>
        <comment>this is for the tracker filter</comment>
        <translation>Alla (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="206"/>
        <source>Trackerless (0)</source>
        <translation>Bevakarlös (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="209"/>
        <source>Error (0)</source>
        <translation>Fel (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="212"/>
        <source>Warning (0)</source>
        <translation>Varning (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="257"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="312"/>
        <source>Trackerless (%1)</source>
        <translation>Bevakarlös (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="354"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="386"/>
        <source>Error (%1)</source>
        <translation>Fel (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="367"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="401"/>
        <source>Warning (%1)</source>
        <translation>Varning (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="462"/>
        <source>Resume torrents</source>
        <translation>Återuppta torrenter</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="463"/>
        <source>Pause torrents</source>
        <translation>Pausa torrenter</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="464"/>
        <source>Delete torrents</source>
        <translation>Ta bort torrenter</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="498"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="512"/>
        <source>All (%1)</source>
        <comment>this is for the tracker filter</comment>
        <translation>Alla (%1)</translation>
    </message>
</context>
<context>
    <name>TrackerListWidget</name>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="261"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="351"/>
        <source>Working</source>
        <translation type="unfinished">Arbetar</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="262"/>
        <source>Disabled</source>
        <translation>Inaktiverad</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="283"/>
        <source>This torrent is private</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="355"/>
        <source>Updating...</source>
        <translation type="unfinished">Uppdaterar...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="359"/>
        <source>Not working</source>
        <translation type="unfinished">Arbetar inte</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="363"/>
        <source>Not contacted yet</source>
        <translation type="unfinished">Inte kontaktade ännu</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="370"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="371"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="372"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="374"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="375"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="376"/>
        <source>N/A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="462"/>
        <source>Tracker editing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="462"/>
        <source>Tracker URL:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="467"/>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="477"/>
        <source>Tracker editing failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="467"/>
        <source>The tracker URL entered is invalid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="477"/>
        <source>The tracker URL already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="531"/>
        <source>Add a new tracker...</source>
        <translation>Lägg till ny bevakare...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="536"/>
        <source>Remove tracker</source>
        <translation>Ta bort bevakare</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="537"/>
        <source>Copy tracker URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="538"/>
        <source>Edit selected tracker URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="543"/>
        <source>Force reannounce to selected trackers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="545"/>
        <source>Force reannounce to all trackers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="592"/>
        <source>URL</source>
        <translation>Webbadress</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="593"/>
        <source>Status</source>
        <translation>Tillstånd</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="594"/>
        <source>Received</source>
        <translation>Mottaget</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="595"/>
        <source>Seeds</source>
        <translation>Delningar</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="596"/>
        <source>Peers</source>
        <translation>Noder</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="597"/>
        <source>Downloaded</source>
        <translation>Hämtat</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="598"/>
        <source>Message</source>
        <translation>Meddelande</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlistwidget.cpp" line="618"/>
        <source>Column visibility</source>
        <translation type="unfinished">Kolumnsynlighet</translation>
    </message>
</context>
<context>
    <name>TrackerLoginDialog</name>
    <message>
        <location filename="../gui/trackerlogindialog.ui" line="14"/>
        <location filename="../gui/trackerlogindialog.ui" line="47"/>
        <source>Tracker authentication</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/trackerlogindialog.ui" line="64"/>
        <source>Tracker:</source>
        <translation>Bevakare:</translation>
    </message>
    <message>
        <location filename="../gui/trackerlogindialog.ui" line="86"/>
        <source>Login</source>
        <translation>Logga in</translation>
    </message>
    <message>
        <location filename="../gui/trackerlogindialog.ui" line="94"/>
        <source>Username:</source>
        <translation>Användarnamn:</translation>
    </message>
    <message>
        <location filename="../gui/trackerlogindialog.ui" line="117"/>
        <source>Password:</source>
        <translation>Lösenord:</translation>
    </message>
    <message>
        <location filename="../gui/trackerlogindialog.cpp" line="46"/>
        <source>Log in</source>
        <translation>Logga in</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDialog</name>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.ui" line="14"/>
        <source>Trackers addition dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.ui" line="20"/>
        <source>List of trackers to add (one per line):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.ui" line="37"/>
        <source>µTorrent compatible list URL:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="116"/>
        <source>No change</source>
        <translation>Ingen ändring</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="116"/>
        <source>No additional trackers were found.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="124"/>
        <source>Download error</source>
        <translation>Hämtningsfel</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondialog.cpp" line="124"/>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="231"/>
        <source>Downloading</source>
        <translation>Hämtar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="237"/>
        <source>Downloading metadata</source>
        <comment>used when loading a magnet link</comment>
        <translation>Hämtar metadata</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="243"/>
        <source>Allocating</source>
        <comment>qBittorrent is allocating the files on disk</comment>
        <translation>Allokerar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="269"/>
        <source>Paused</source>
        <translation>Pausad</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="254"/>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>Kölagd</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="247"/>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Distribuerar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="234"/>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Avstannad</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="240"/>
        <source>[F] Downloading</source>
        <comment>used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Laddar ner</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="250"/>
        <source>[F] Seeding</source>
        <comment>used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Distribuerar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="258"/>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Kontrollerar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="262"/>
        <source>Queued for checking</source>
        <comment>i.e. torrent is queued for hash checking</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="266"/>
        <source>Checking resume data</source>
        <comment>used when loading the torrents from disk after qbt is launched. It checks the correctness of the .fastresume file. Normally it is completed in a fraction of a second, unless loading many many torrents.</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="272"/>
        <source>Completed</source>
        <translation>Färdiga</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="275"/>
        <source>Moving</source>
        <comment>Torrent local data are being moved/relocated</comment>
        <translation>Flyttar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="278"/>
        <source>Missing Files</source>
        <translation>Saknade filer</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="281"/>
        <source>Errored</source>
        <comment>torrent status, the torrent has an error</comment>
        <translation>Felaktiga</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="127"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (distribuerad för %2)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="188"/>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>%1 sedan</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="591"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="599"/>
        <source>Categories</source>
        <translation>Kategorier</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="618"/>
        <source>Tags</source>
        <translation>Taggar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="636"/>
        <source>Trackers</source>
        <translation>Bevakare</translation>
    </message>
</context>
<context>
    <name>TransferListModel</name>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="97"/>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="98"/>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Storlek</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="99"/>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Färdig</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="100"/>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Tillstånd</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="101"/>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Distributeringar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="102"/>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Noder</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="103"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Hämtningshastighet</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="104"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Sändningshastighet</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="105"/>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Förhållande</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="106"/>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="107"/>
        <source>Category</source>
        <translation>Kategori</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="108"/>
        <source>Tags</source>
        <translation>Taggar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="109"/>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="110"/>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="111"/>
        <source>Tracker</source>
        <translation>Bevakare</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="112"/>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Hämtningsgräns</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="113"/>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Sändningsgräns</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="114"/>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Hämtat</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="115"/>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>Sänt</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="116"/>
        <source>Session Download</source>
        <comment>Amount of data downloaded since program open (e.g. in MB)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="117"/>
        <source>Session Upload</source>
        <comment>Amount of data uploaded since program open (e.g. in MB)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="118"/>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation type="unfinished">Återstår</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="119"/>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="120"/>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>Spara sökväg</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="121"/>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation type="unfinished">Färdiga</translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="122"/>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="123"/>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="124"/>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistmodel.cpp" line="125"/>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>Total storlek</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="703"/>
        <source>Column visibility</source>
        <translation>Kolumnsynlighet</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="398"/>
        <source>Choose save path</source>
        <translation>Välj sökväg att spara i</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="616"/>
        <source>Torrent Download Speed Limiting</source>
        <translation>Hastighetsgräns för torrenthämtning</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="641"/>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Hastighetsgräns för torrentsändning</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="685"/>
        <source>Recheck confirmation</source>
        <translation>Bekräftelse om återkontroll</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="685"/>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="832"/>
        <source>Rename</source>
        <translation>Byt namn</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="832"/>
        <source>New name:</source>
        <translation>Nytt namn:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="867"/>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Återuppta</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="871"/>
        <source>Force Resume</source>
        <comment>Force Resume/start the torrent</comment>
        <translation>Tvinga Återupptagning</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="869"/>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Gör paus</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="405"/>
        <source>Set location: moving &quot;%1&quot;, from &quot;%2&quot; to &quot;%3&quot;</source>
        <comment>Set location: moving &quot;ubuntu_16_04.iso&quot;, from &quot;/home/dir1&quot; to &quot;/home/dir2&quot;</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="774"/>
        <source>Add Tags</source>
        <translation>Lägg till taggar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="782"/>
        <source>Remove All Tags</source>
        <translation>Ta bort alla taggar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="782"/>
        <source>Remove all tags from selected torrents?</source>
        <translation>Ta bort alla taggar från valda torrenter?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="796"/>
        <source>Comma-separated tags:</source>
        <translation>Kommaseparerade taggar:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="803"/>
        <source>Invalid tag</source>
        <translation>Ogiltig tagg</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="804"/>
        <source>Tag name: &apos;%1&apos; is invalid</source>
        <translation>Taggnamn: &apos;%1&apos; är ogiltig</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="873"/>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="875"/>
        <source>Preview file...</source>
        <translation>Förhandsgranska fil...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="877"/>
        <source>Limit share ratio...</source>
        <translation>Begränsa utdelningsförhållande...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="879"/>
        <source>Limit upload rate...</source>
        <translation>Begränsa sändningshastighet...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="881"/>
        <source>Limit download rate...</source>
        <translation>Begränsa hämtningshastighet...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="883"/>
        <source>Open destination folder</source>
        <translation>Öppna målmapp</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="885"/>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Flytta uppåt</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="887"/>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Flytta nedåt</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="889"/>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Flytta överst</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="891"/>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Flytta nederst</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="893"/>
        <source>Set location...</source>
        <translation>Ange plats...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="897"/>
        <source>Force reannounce</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="901"/>
        <source>Copy name</source>
        <translation>Kopiera namn</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="903"/>
        <source>Copy hash</source>
        <translation>Kopiera hash</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="913"/>
        <source>Download first and last pieces first</source>
        <translation>Hämta första och sista bitarna först</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="916"/>
        <source>Automatic Torrent Management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="918"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation type="unfinished">Automatiskt läge betyder att vissa torrentegenskaper (t.ex. var filen ska sparas) bestäms av filens kategori</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1021"/>
        <source>Category</source>
        <translation>Kategori</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1022"/>
        <source>New...</source>
        <comment>New category...</comment>
        <translation>Ny...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1023"/>
        <source>Reset</source>
        <comment>Reset category</comment>
        <translation>Återställ</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1040"/>
        <source>Tags</source>
        <translation>Taggar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1041"/>
        <source>Add...</source>
        <comment>Add / assign multiple tags...</comment>
        <translation>Lägg till...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1042"/>
        <source>Remove All</source>
        <comment>Remove all tags</comment>
        <translation>Ta bort alla</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1104"/>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="895"/>
        <source>Force recheck</source>
        <translation>Tvinga återkontroll</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="899"/>
        <source>Copy magnet link</source>
        <translation>Kopiera magnetlänk</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="905"/>
        <source>Super seeding mode</source>
        <translation>Superdistributionsläge</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="908"/>
        <source>Rename...</source>
        <translation>Byt namn...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="910"/>
        <source>Download in sequential order</source>
        <translation>Hämta i sekventiell ordning</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDialog</name>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="14"/>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="20"/>
        <source>Use global share limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="23"/>
        <location filename="../gui/updownratiodialog.ui" line="33"/>
        <location filename="../gui/updownratiodialog.ui" line="45"/>
        <source>buttonGroup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="30"/>
        <source>Set no share limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="42"/>
        <source>Set share limit to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="100"/>
        <source>ratio</source>
        <translation>förhållande</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.ui" line="107"/>
        <source>minutes</source>
        <translation>minuter</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.cpp" line="85"/>
        <source>No share limit method selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/updownratiodialog.cpp" line="86"/>
        <source>Please select a limit method first</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Utils::ForeignApps</name>
    <message>
        <location filename="../base/utils/foreignapps.cpp" line="72"/>
        <source>Python detected, version: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/utils/foreignapps.cpp" line="102"/>
        <source>Python not detected</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WebApplication</name>
    <message>
        <location filename="../webui/webapplication.cpp" line="221"/>
        <source>Unacceptable file type, only regular file is allowed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="228"/>
        <source>Symlinks inside alternative UI folder are forbidden.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="480"/>
        <source>Exceeded the maximum allowed file size (%1)!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="690"/>
        <source>WebUI: Origin header &amp; Target origin mismatch! Source IP: &apos;%1&apos;. Origin header: &apos;%2&apos;. Target origin: &apos;%3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="699"/>
        <source>WebUI: Referer header &amp; Target origin mismatch! Source IP: &apos;%1&apos;. Referer header: &apos;%2&apos;. Target origin: &apos;%3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="716"/>
        <source>WebUI: Invalid Host header, port mismatch. Request source IP: &apos;%1&apos;. Server port: &apos;%2&apos;. Received Host header: &apos;%3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="748"/>
        <source>WebUI: Invalid Host header. Request source IP: &apos;%1&apos;. Received Host header: &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WebUI</name>
    <message>
        <location filename="../webui/webui.cpp" line="86"/>
        <source>Web UI: HTTPS setup successful</source>
        <translation>Webbgränssnitt: HTTPS-inställningen lyckades</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="88"/>
        <source>Web UI: HTTPS setup failed, fallback to HTTP</source>
        <translation>Webgränssnitt: HTTPS-inställningen misslyckades, återgång till HTTP</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="100"/>
        <source>Web UI: Now listening on IP: %1, port: %2</source>
        <translation>Webbgränssnitt: Lyssnar nu på IP: %1, port: %2</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="103"/>
        <source>Web UI: Unable to bind to IP: %1, port: %2. Reason: %3</source>
        <translation>Webbgränssnitt: Kan inte binda till IP: %1, port: %2. Anledning: %3</translation>
    </message>
</context>
<context>
    <name>fsutils</name>
    <message>
        <location filename="../base/private/profile_p.cpp" line="92"/>
        <source>Downloads</source>
        <translation>Hämtningar</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <location filename="../base/utils/misc.cpp" line="79"/>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="80"/>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="81"/>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="82"/>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="83"/>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="84"/>
        <source>PiB</source>
        <comment>pebibytes (1024 tebibytes)</comment>
        <translation>PiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="85"/>
        <source>EiB</source>
        <comment>exbibytes (1024 pebibytes)</comment>
        <translation>EiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="279"/>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="366"/>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1h %2m</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="371"/>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1d %2h</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="272"/>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Okänd</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="125"/>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>qBittorrent kommer nu att stänga av datorn därför att alla hämtningar är färdiga.</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="357"/>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1 min</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="361"/>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1 min</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <location filename="../gui/previewselectdialog.ui" line="14"/>
        <source>Preview selection</source>
        <translation>Förhandsvisa markering</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.ui" line="20"/>
        <source>The following files support previewing, please select one of them:</source>
        <translation>Följande filer har stöd för förhandsvisning, välj en av dem:</translation>
    </message>
</context>
</TS>
