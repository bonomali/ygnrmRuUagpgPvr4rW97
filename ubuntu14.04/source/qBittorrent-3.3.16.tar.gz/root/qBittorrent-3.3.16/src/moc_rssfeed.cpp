/****************************************************************************
** Meta object code from reading C++ file 'rssfeed.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "base/rss/rssfeed.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'rssfeed.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Rss__Feed_t {
    QByteArrayData data[15];
    char stringdata0[199];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Rss__Feed_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Rss__Feed_t qt_meta_stringdata_Rss__Feed = {
    {
QT_MOC_LITERAL(0, 0, 9), // "Rss::Feed"
QT_MOC_LITERAL(1, 10, 26), // "handleIconDownloadFinished"
QT_MOC_LITERAL(2, 37, 0), // ""
QT_MOC_LITERAL(3, 38, 3), // "url"
QT_MOC_LITERAL(4, 42, 8), // "filePath"
QT_MOC_LITERAL(5, 51, 25), // "handleRssDownloadFinished"
QT_MOC_LITERAL(6, 77, 4), // "data"
QT_MOC_LITERAL(7, 82, 23), // "handleRssDownloadFailed"
QT_MOC_LITERAL(8, 106, 5), // "error"
QT_MOC_LITERAL(9, 112, 15), // "handleFeedTitle"
QT_MOC_LITERAL(10, 128, 5), // "title"
QT_MOC_LITERAL(11, 134, 16), // "handleNewArticle"
QT_MOC_LITERAL(12, 151, 7), // "article"
QT_MOC_LITERAL(13, 159, 21), // "handleParsingFinished"
QT_MOC_LITERAL(14, 181, 17) // "handleArticleRead"

    },
    "Rss::Feed\0handleIconDownloadFinished\0"
    "\0url\0filePath\0handleRssDownloadFinished\0"
    "data\0handleRssDownloadFailed\0error\0"
    "handleFeedTitle\0title\0handleNewArticle\0"
    "article\0handleParsingFinished\0"
    "handleArticleRead"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Rss__Feed[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    2,   49,    2, 0x08 /* Private */,
       5,    2,   54,    2, 0x08 /* Private */,
       7,    2,   59,    2, 0x08 /* Private */,
       9,    1,   64,    2, 0x08 /* Private */,
      11,    1,   67,    2, 0x08 /* Private */,
      13,    1,   70,    2, 0x08 /* Private */,
      14,    0,   73,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    3,    4,
    QMetaType::Void, QMetaType::QString, QMetaType::QByteArray,    3,    6,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    3,    8,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void, QMetaType::QVariantHash,   12,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void,

       0        // eod
};

void Rss::Feed::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Feed *_t = static_cast<Feed *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->handleIconDownloadFinished((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 1: _t->handleRssDownloadFinished((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QByteArray(*)>(_a[2]))); break;
        case 2: _t->handleRssDownloadFailed((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 3: _t->handleFeedTitle((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->handleNewArticle((*reinterpret_cast< const QVariantHash(*)>(_a[1]))); break;
        case 5: _t->handleParsingFinished((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 6: _t->handleArticleRead(); break;
        default: ;
        }
    }
}

const QMetaObject Rss::Feed::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_Rss__Feed.data,
      qt_meta_data_Rss__Feed,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *Rss::Feed::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Rss::Feed::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_Rss__Feed.stringdata0))
        return static_cast<void*>(const_cast< Feed*>(this));
    if (!strcmp(_clname, "File"))
        return static_cast< File*>(const_cast< Feed*>(this));
    return QObject::qt_metacast(_clname);
}

int Rss::Feed::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 7;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
