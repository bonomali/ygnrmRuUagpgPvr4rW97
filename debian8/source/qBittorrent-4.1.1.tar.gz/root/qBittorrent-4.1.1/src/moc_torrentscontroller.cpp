/****************************************************************************
** Meta object code from reading C++ file 'torrentscontroller.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "webui/api/torrentscontroller.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'torrentscontroller.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_TorrentsController_t {
    QByteArrayData data[39];
    char stringdata0[689];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_TorrentsController_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_TorrentsController_t qt_meta_stringdata_TorrentsController = {
    {
QT_MOC_LITERAL(0, 0, 18), // "TorrentsController"
QT_MOC_LITERAL(1, 19, 10), // "infoAction"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 16), // "propertiesAction"
QT_MOC_LITERAL(4, 48, 14), // "trackersAction"
QT_MOC_LITERAL(5, 63, 14), // "webseedsAction"
QT_MOC_LITERAL(6, 78, 11), // "filesAction"
QT_MOC_LITERAL(7, 90, 17), // "pieceHashesAction"
QT_MOC_LITERAL(8, 108, 17), // "pieceStatesAction"
QT_MOC_LITERAL(9, 126, 12), // "resumeAction"
QT_MOC_LITERAL(10, 139, 11), // "pauseAction"
QT_MOC_LITERAL(11, 151, 13), // "recheckAction"
QT_MOC_LITERAL(12, 165, 16), // "reannounceAction"
QT_MOC_LITERAL(13, 182, 12), // "renameAction"
QT_MOC_LITERAL(14, 195, 17), // "setCategoryAction"
QT_MOC_LITERAL(15, 213, 20), // "createCategoryAction"
QT_MOC_LITERAL(16, 234, 18), // "editCategoryAction"
QT_MOC_LITERAL(17, 253, 22), // "removeCategoriesAction"
QT_MOC_LITERAL(18, 276, 9), // "addAction"
QT_MOC_LITERAL(19, 286, 12), // "deleteAction"
QT_MOC_LITERAL(20, 299, 17), // "addTrackersAction"
QT_MOC_LITERAL(21, 317, 17), // "editTrackerAction"
QT_MOC_LITERAL(22, 335, 20), // "removeTrackersAction"
QT_MOC_LITERAL(23, 356, 14), // "filePrioAction"
QT_MOC_LITERAL(24, 371, 17), // "uploadLimitAction"
QT_MOC_LITERAL(25, 389, 19), // "downloadLimitAction"
QT_MOC_LITERAL(26, 409, 20), // "setUploadLimitAction"
QT_MOC_LITERAL(27, 430, 22), // "setDownloadLimitAction"
QT_MOC_LITERAL(28, 453, 20), // "setShareLimitsAction"
QT_MOC_LITERAL(29, 474, 18), // "increasePrioAction"
QT_MOC_LITERAL(30, 493, 18), // "decreasePrioAction"
QT_MOC_LITERAL(31, 512, 13), // "topPrioAction"
QT_MOC_LITERAL(32, 526, 16), // "bottomPrioAction"
QT_MOC_LITERAL(33, 543, 17), // "setLocationAction"
QT_MOC_LITERAL(34, 561, 23), // "setAutoManagementAction"
QT_MOC_LITERAL(35, 585, 21), // "setSuperSeedingAction"
QT_MOC_LITERAL(36, 607, 19), // "setForceStartAction"
QT_MOC_LITERAL(37, 627, 30), // "toggleSequentialDownloadAction"
QT_MOC_LITERAL(38, 658, 30) // "toggleFirstLastPiecePrioAction"

    },
    "TorrentsController\0infoAction\0\0"
    "propertiesAction\0trackersAction\0"
    "webseedsAction\0filesAction\0pieceHashesAction\0"
    "pieceStatesAction\0resumeAction\0"
    "pauseAction\0recheckAction\0reannounceAction\0"
    "renameAction\0setCategoryAction\0"
    "createCategoryAction\0editCategoryAction\0"
    "removeCategoriesAction\0addAction\0"
    "deleteAction\0addTrackersAction\0"
    "editTrackerAction\0removeTrackersAction\0"
    "filePrioAction\0uploadLimitAction\0"
    "downloadLimitAction\0setUploadLimitAction\0"
    "setDownloadLimitAction\0setShareLimitsAction\0"
    "increasePrioAction\0decreasePrioAction\0"
    "topPrioAction\0bottomPrioAction\0"
    "setLocationAction\0setAutoManagementAction\0"
    "setSuperSeedingAction\0setForceStartAction\0"
    "toggleSequentialDownloadAction\0"
    "toggleFirstLastPiecePrioAction"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_TorrentsController[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      37,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  199,    2, 0x08 /* Private */,
       3,    0,  200,    2, 0x08 /* Private */,
       4,    0,  201,    2, 0x08 /* Private */,
       5,    0,  202,    2, 0x08 /* Private */,
       6,    0,  203,    2, 0x08 /* Private */,
       7,    0,  204,    2, 0x08 /* Private */,
       8,    0,  205,    2, 0x08 /* Private */,
       9,    0,  206,    2, 0x08 /* Private */,
      10,    0,  207,    2, 0x08 /* Private */,
      11,    0,  208,    2, 0x08 /* Private */,
      12,    0,  209,    2, 0x08 /* Private */,
      13,    0,  210,    2, 0x08 /* Private */,
      14,    0,  211,    2, 0x08 /* Private */,
      15,    0,  212,    2, 0x08 /* Private */,
      16,    0,  213,    2, 0x08 /* Private */,
      17,    0,  214,    2, 0x08 /* Private */,
      18,    0,  215,    2, 0x08 /* Private */,
      19,    0,  216,    2, 0x08 /* Private */,
      20,    0,  217,    2, 0x08 /* Private */,
      21,    0,  218,    2, 0x08 /* Private */,
      22,    0,  219,    2, 0x08 /* Private */,
      23,    0,  220,    2, 0x08 /* Private */,
      24,    0,  221,    2, 0x08 /* Private */,
      25,    0,  222,    2, 0x08 /* Private */,
      26,    0,  223,    2, 0x08 /* Private */,
      27,    0,  224,    2, 0x08 /* Private */,
      28,    0,  225,    2, 0x08 /* Private */,
      29,    0,  226,    2, 0x08 /* Private */,
      30,    0,  227,    2, 0x08 /* Private */,
      31,    0,  228,    2, 0x08 /* Private */,
      32,    0,  229,    2, 0x08 /* Private */,
      33,    0,  230,    2, 0x08 /* Private */,
      34,    0,  231,    2, 0x08 /* Private */,
      35,    0,  232,    2, 0x08 /* Private */,
      36,    0,  233,    2, 0x08 /* Private */,
      37,    0,  234,    2, 0x08 /* Private */,
      38,    0,  235,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void TorrentsController::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        TorrentsController *_t = static_cast<TorrentsController *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->infoAction(); break;
        case 1: _t->propertiesAction(); break;
        case 2: _t->trackersAction(); break;
        case 3: _t->webseedsAction(); break;
        case 4: _t->filesAction(); break;
        case 5: _t->pieceHashesAction(); break;
        case 6: _t->pieceStatesAction(); break;
        case 7: _t->resumeAction(); break;
        case 8: _t->pauseAction(); break;
        case 9: _t->recheckAction(); break;
        case 10: _t->reannounceAction(); break;
        case 11: _t->renameAction(); break;
        case 12: _t->setCategoryAction(); break;
        case 13: _t->createCategoryAction(); break;
        case 14: _t->editCategoryAction(); break;
        case 15: _t->removeCategoriesAction(); break;
        case 16: _t->addAction(); break;
        case 17: _t->deleteAction(); break;
        case 18: _t->addTrackersAction(); break;
        case 19: _t->editTrackerAction(); break;
        case 20: _t->removeTrackersAction(); break;
        case 21: _t->filePrioAction(); break;
        case 22: _t->uploadLimitAction(); break;
        case 23: _t->downloadLimitAction(); break;
        case 24: _t->setUploadLimitAction(); break;
        case 25: _t->setDownloadLimitAction(); break;
        case 26: _t->setShareLimitsAction(); break;
        case 27: _t->increasePrioAction(); break;
        case 28: _t->decreasePrioAction(); break;
        case 29: _t->topPrioAction(); break;
        case 30: _t->bottomPrioAction(); break;
        case 31: _t->setLocationAction(); break;
        case 32: _t->setAutoManagementAction(); break;
        case 33: _t->setSuperSeedingAction(); break;
        case 34: _t->setForceStartAction(); break;
        case 35: _t->toggleSequentialDownloadAction(); break;
        case 36: _t->toggleFirstLastPiecePrioAction(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject TorrentsController::staticMetaObject = {
    { &APIController::staticMetaObject, qt_meta_stringdata_TorrentsController.data,
      qt_meta_data_TorrentsController,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *TorrentsController::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TorrentsController::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_TorrentsController.stringdata0))
        return static_cast<void*>(const_cast< TorrentsController*>(this));
    return APIController::qt_metacast(_clname);
}

int TorrentsController::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = APIController::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 37)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 37;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 37)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 37;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
