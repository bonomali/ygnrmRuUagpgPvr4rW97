/****************************************************************************
** Meta object code from reading C++ file 'session.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "base/bittorrent/session.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'session.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_BitTorrent__Session_t {
    QByteArrayData data[69];
    char stringdata0[1152];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_BitTorrent__Session_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_BitTorrent__Session_t qt_meta_stringdata_BitTorrent__Session = {
    {
QT_MOC_LITERAL(0, 0, 19), // "BitTorrent::Session"
QT_MOC_LITERAL(1, 20, 15), // "torrentsUpdated"
QT_MOC_LITERAL(2, 36, 0), // ""
QT_MOC_LITERAL(3, 37, 16), // "addTorrentFailed"
QT_MOC_LITERAL(4, 54, 5), // "error"
QT_MOC_LITERAL(5, 60, 12), // "torrentAdded"
QT_MOC_LITERAL(6, 73, 31), // "BitTorrent::TorrentHandle*const"
QT_MOC_LITERAL(7, 105, 7), // "torrent"
QT_MOC_LITERAL(8, 113, 10), // "torrentNew"
QT_MOC_LITERAL(9, 124, 23), // "torrentAboutToBeRemoved"
QT_MOC_LITERAL(10, 148, 13), // "torrentPaused"
QT_MOC_LITERAL(11, 162, 14), // "torrentResumed"
QT_MOC_LITERAL(12, 177, 15), // "torrentFinished"
QT_MOC_LITERAL(13, 193, 23), // "torrentFinishedChecking"
QT_MOC_LITERAL(14, 217, 22), // "torrentSavePathChanged"
QT_MOC_LITERAL(15, 240, 22), // "torrentCategoryChanged"
QT_MOC_LITERAL(16, 263, 11), // "oldCategory"
QT_MOC_LITERAL(17, 275, 24), // "torrentSavingModeChanged"
QT_MOC_LITERAL(18, 300, 19), // "allTorrentsFinished"
QT_MOC_LITERAL(19, 320, 14), // "metadataLoaded"
QT_MOC_LITERAL(20, 335, 23), // "BitTorrent::TorrentInfo"
QT_MOC_LITERAL(21, 359, 4), // "info"
QT_MOC_LITERAL(22, 364, 21), // "torrentMetadataLoaded"
QT_MOC_LITERAL(23, 386, 13), // "fullDiskError"
QT_MOC_LITERAL(24, 400, 3), // "msg"
QT_MOC_LITERAL(25, 404, 14), // "trackerSuccess"
QT_MOC_LITERAL(26, 419, 7), // "tracker"
QT_MOC_LITERAL(27, 427, 14), // "trackerWarning"
QT_MOC_LITERAL(28, 442, 12), // "trackerError"
QT_MOC_LITERAL(29, 455, 29), // "trackerAuthenticationRequired"
QT_MOC_LITERAL(30, 485, 32), // "recursiveTorrentDownloadPossible"
QT_MOC_LITERAL(31, 518, 21), // "speedLimitModeChanged"
QT_MOC_LITERAL(32, 540, 11), // "alternative"
QT_MOC_LITERAL(33, 552, 14), // "IPFilterParsed"
QT_MOC_LITERAL(34, 567, 9), // "ruleCount"
QT_MOC_LITERAL(35, 577, 13), // "trackersAdded"
QT_MOC_LITERAL(36, 591, 31), // "QList<BitTorrent::TrackerEntry>"
QT_MOC_LITERAL(37, 623, 8), // "trackers"
QT_MOC_LITERAL(38, 632, 15), // "trackersRemoved"
QT_MOC_LITERAL(39, 648, 15), // "trackersChanged"
QT_MOC_LITERAL(40, 664, 23), // "trackerlessStateChanged"
QT_MOC_LITERAL(41, 688, 11), // "trackerless"
QT_MOC_LITERAL(42, 700, 21), // "downloadFromUrlFailed"
QT_MOC_LITERAL(43, 722, 3), // "url"
QT_MOC_LITERAL(44, 726, 6), // "reason"
QT_MOC_LITERAL(45, 733, 23), // "downloadFromUrlFinished"
QT_MOC_LITERAL(46, 757, 13), // "categoryAdded"
QT_MOC_LITERAL(47, 771, 12), // "categoryName"
QT_MOC_LITERAL(48, 784, 15), // "categoryRemoved"
QT_MOC_LITERAL(49, 800, 27), // "subcategoriesSupportChanged"
QT_MOC_LITERAL(50, 828, 17), // "configureDeferred"
QT_MOC_LITERAL(51, 846, 10), // "readAlerts"
QT_MOC_LITERAL(52, 857, 7), // "refresh"
QT_MOC_LITERAL(53, 865, 16), // "processBigRatios"
QT_MOC_LITERAL(54, 882, 18), // "generateResumeData"
QT_MOC_LITERAL(55, 901, 5), // "final"
QT_MOC_LITERAL(56, 907, 20), // "handleIPFilterParsed"
QT_MOC_LITERAL(57, 928, 19), // "handleIPFilterError"
QT_MOC_LITERAL(58, 948, 22), // "handleDownloadFinished"
QT_MOC_LITERAL(59, 971, 8), // "filePath"
QT_MOC_LITERAL(60, 980, 20), // "handleDownloadFailed"
QT_MOC_LITERAL(61, 1001, 24), // "handleRedirectedToMagnet"
QT_MOC_LITERAL(62, 1026, 9), // "magnetUri"
QT_MOC_LITERAL(63, 1036, 23), // "switchToAlternativeMode"
QT_MOC_LITERAL(64, 1060, 25), // "networkOnlineStateChanged"
QT_MOC_LITERAL(65, 1086, 6), // "online"
QT_MOC_LITERAL(66, 1093, 26), // "networkConfigurationChange"
QT_MOC_LITERAL(67, 1120, 21), // "QNetworkConfiguration"
QT_MOC_LITERAL(68, 1142, 9) // "configure"

    },
    "BitTorrent::Session\0torrentsUpdated\0"
    "\0addTorrentFailed\0error\0torrentAdded\0"
    "BitTorrent::TorrentHandle*const\0torrent\0"
    "torrentNew\0torrentAboutToBeRemoved\0"
    "torrentPaused\0torrentResumed\0"
    "torrentFinished\0torrentFinishedChecking\0"
    "torrentSavePathChanged\0torrentCategoryChanged\0"
    "oldCategory\0torrentSavingModeChanged\0"
    "allTorrentsFinished\0metadataLoaded\0"
    "BitTorrent::TorrentInfo\0info\0"
    "torrentMetadataLoaded\0fullDiskError\0"
    "msg\0trackerSuccess\0tracker\0trackerWarning\0"
    "trackerError\0trackerAuthenticationRequired\0"
    "recursiveTorrentDownloadPossible\0"
    "speedLimitModeChanged\0alternative\0"
    "IPFilterParsed\0ruleCount\0trackersAdded\0"
    "QList<BitTorrent::TrackerEntry>\0"
    "trackers\0trackersRemoved\0trackersChanged\0"
    "trackerlessStateChanged\0trackerless\0"
    "downloadFromUrlFailed\0url\0reason\0"
    "downloadFromUrlFinished\0categoryAdded\0"
    "categoryName\0categoryRemoved\0"
    "subcategoriesSupportChanged\0"
    "configureDeferred\0readAlerts\0refresh\0"
    "processBigRatios\0generateResumeData\0"
    "final\0handleIPFilterParsed\0"
    "handleIPFilterError\0handleDownloadFinished\0"
    "filePath\0handleDownloadFailed\0"
    "handleRedirectedToMagnet\0magnetUri\0"
    "switchToAlternativeMode\0"
    "networkOnlineStateChanged\0online\0"
    "networkConfigurationChange\0"
    "QNetworkConfiguration\0configure"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_BitTorrent__Session[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      47,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      32,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  249,    2, 0x06 /* Public */,
       3,    1,  250,    2, 0x06 /* Public */,
       5,    1,  253,    2, 0x06 /* Public */,
       8,    1,  256,    2, 0x06 /* Public */,
       9,    1,  259,    2, 0x06 /* Public */,
      10,    1,  262,    2, 0x06 /* Public */,
      11,    1,  265,    2, 0x06 /* Public */,
      12,    1,  268,    2, 0x06 /* Public */,
      13,    1,  271,    2, 0x06 /* Public */,
      14,    1,  274,    2, 0x06 /* Public */,
      15,    2,  277,    2, 0x06 /* Public */,
      17,    1,  282,    2, 0x06 /* Public */,
      18,    0,  285,    2, 0x06 /* Public */,
      19,    1,  286,    2, 0x06 /* Public */,
      22,    1,  289,    2, 0x06 /* Public */,
      23,    2,  292,    2, 0x06 /* Public */,
      25,    2,  297,    2, 0x06 /* Public */,
      27,    2,  302,    2, 0x06 /* Public */,
      28,    2,  307,    2, 0x06 /* Public */,
      29,    1,  312,    2, 0x06 /* Public */,
      30,    1,  315,    2, 0x06 /* Public */,
      31,    1,  318,    2, 0x06 /* Public */,
      33,    2,  321,    2, 0x06 /* Public */,
      35,    2,  326,    2, 0x06 /* Public */,
      38,    2,  331,    2, 0x06 /* Public */,
      39,    1,  336,    2, 0x06 /* Public */,
      40,    2,  339,    2, 0x06 /* Public */,
      42,    2,  344,    2, 0x06 /* Public */,
      45,    1,  349,    2, 0x06 /* Public */,
      46,    1,  352,    2, 0x06 /* Public */,
      48,    1,  355,    2, 0x06 /* Public */,
      49,    0,  358,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      50,    0,  359,    2, 0x08 /* Private */,
      51,    0,  360,    2, 0x08 /* Private */,
      52,    0,  361,    2, 0x08 /* Private */,
      53,    0,  362,    2, 0x08 /* Private */,
      54,    1,  363,    2, 0x08 /* Private */,
      54,    0,  366,    2, 0x28 /* Private | MethodCloned */,
      56,    1,  367,    2, 0x08 /* Private */,
      57,    0,  370,    2, 0x08 /* Private */,
      58,    2,  371,    2, 0x08 /* Private */,
      60,    2,  376,    2, 0x08 /* Private */,
      61,    2,  381,    2, 0x08 /* Private */,
      63,    1,  386,    2, 0x08 /* Private */,
      64,    1,  389,    2, 0x08 /* Private */,
      66,    1,  392,    2, 0x08 /* Private */,

 // methods: name, argc, parameters, tag, flags
      68,    0,  395,    2, 0x00 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 6, QMetaType::QString,    7,   16,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 20,   21,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 6, QMetaType::QString,    7,   24,
    QMetaType::Void, 0x80000000 | 6, QMetaType::QString,    7,   26,
    QMetaType::Void, 0x80000000 | 6, QMetaType::QString,    7,   26,
    QMetaType::Void, 0x80000000 | 6, QMetaType::QString,    7,   26,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, QMetaType::Bool,   32,
    QMetaType::Void, QMetaType::Bool, QMetaType::Int,    4,   34,
    QMetaType::Void, 0x80000000 | 6, 0x80000000 | 36,    7,   37,
    QMetaType::Void, 0x80000000 | 6, 0x80000000 | 36,    7,   37,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 6, QMetaType::Bool,    7,   41,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   43,   44,
    QMetaType::Void, QMetaType::QString,   43,
    QMetaType::Void, QMetaType::QString,   47,
    QMetaType::Void, QMetaType::QString,   47,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   55,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   34,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   43,   59,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   43,   44,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   43,   62,
    QMetaType::Void, QMetaType::Bool,   32,
    QMetaType::Void, QMetaType::Bool,   65,
    QMetaType::Void, 0x80000000 | 67,    2,

 // methods: parameters
    QMetaType::Void,

       0        // eod
};

void BitTorrent::Session::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Session *_t = static_cast<Session *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->torrentsUpdated(); break;
        case 1: _t->addTorrentFailed((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: _t->torrentAdded((*reinterpret_cast< BitTorrent::TorrentHandle*const(*)>(_a[1]))); break;
        case 3: _t->torrentNew((*reinterpret_cast< BitTorrent::TorrentHandle*const(*)>(_a[1]))); break;
        case 4: _t->torrentAboutToBeRemoved((*reinterpret_cast< BitTorrent::TorrentHandle*const(*)>(_a[1]))); break;
        case 5: _t->torrentPaused((*reinterpret_cast< BitTorrent::TorrentHandle*const(*)>(_a[1]))); break;
        case 6: _t->torrentResumed((*reinterpret_cast< BitTorrent::TorrentHandle*const(*)>(_a[1]))); break;
        case 7: _t->torrentFinished((*reinterpret_cast< BitTorrent::TorrentHandle*const(*)>(_a[1]))); break;
        case 8: _t->torrentFinishedChecking((*reinterpret_cast< BitTorrent::TorrentHandle*const(*)>(_a[1]))); break;
        case 9: _t->torrentSavePathChanged((*reinterpret_cast< BitTorrent::TorrentHandle*const(*)>(_a[1]))); break;
        case 10: _t->torrentCategoryChanged((*reinterpret_cast< BitTorrent::TorrentHandle*const(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 11: _t->torrentSavingModeChanged((*reinterpret_cast< BitTorrent::TorrentHandle*const(*)>(_a[1]))); break;
        case 12: _t->allTorrentsFinished(); break;
        case 13: _t->metadataLoaded((*reinterpret_cast< const BitTorrent::TorrentInfo(*)>(_a[1]))); break;
        case 14: _t->torrentMetadataLoaded((*reinterpret_cast< BitTorrent::TorrentHandle*const(*)>(_a[1]))); break;
        case 15: _t->fullDiskError((*reinterpret_cast< BitTorrent::TorrentHandle*const(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 16: _t->trackerSuccess((*reinterpret_cast< BitTorrent::TorrentHandle*const(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 17: _t->trackerWarning((*reinterpret_cast< BitTorrent::TorrentHandle*const(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 18: _t->trackerError((*reinterpret_cast< BitTorrent::TorrentHandle*const(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 19: _t->trackerAuthenticationRequired((*reinterpret_cast< BitTorrent::TorrentHandle*const(*)>(_a[1]))); break;
        case 20: _t->recursiveTorrentDownloadPossible((*reinterpret_cast< BitTorrent::TorrentHandle*const(*)>(_a[1]))); break;
        case 21: _t->speedLimitModeChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 22: _t->IPFilterParsed((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 23: _t->trackersAdded((*reinterpret_cast< BitTorrent::TorrentHandle*const(*)>(_a[1])),(*reinterpret_cast< const QList<BitTorrent::TrackerEntry>(*)>(_a[2]))); break;
        case 24: _t->trackersRemoved((*reinterpret_cast< BitTorrent::TorrentHandle*const(*)>(_a[1])),(*reinterpret_cast< const QList<BitTorrent::TrackerEntry>(*)>(_a[2]))); break;
        case 25: _t->trackersChanged((*reinterpret_cast< BitTorrent::TorrentHandle*const(*)>(_a[1]))); break;
        case 26: _t->trackerlessStateChanged((*reinterpret_cast< BitTorrent::TorrentHandle*const(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 27: _t->downloadFromUrlFailed((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 28: _t->downloadFromUrlFinished((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 29: _t->categoryAdded((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 30: _t->categoryRemoved((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 31: _t->subcategoriesSupportChanged(); break;
        case 32: _t->configureDeferred(); break;
        case 33: _t->readAlerts(); break;
        case 34: _t->refresh(); break;
        case 35: _t->processBigRatios(); break;
        case 36: _t->generateResumeData((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 37: _t->generateResumeData(); break;
        case 38: _t->handleIPFilterParsed((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 39: _t->handleIPFilterError(); break;
        case 40: _t->handleDownloadFinished((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 41: _t->handleDownloadFailed((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 42: _t->handleRedirectedToMagnet((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 43: _t->switchToAlternativeMode((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 44: _t->networkOnlineStateChanged((*reinterpret_cast< const bool(*)>(_a[1]))); break;
        case 45: _t->networkConfigurationChange((*reinterpret_cast< const QNetworkConfiguration(*)>(_a[1]))); break;
        case 46: _t->configure(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 45:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QNetworkConfiguration >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (Session::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::torrentsUpdated)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (Session::*_t)(const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::addTorrentFailed)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (Session::*_t)(BitTorrent::TorrentHandle * const );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::torrentAdded)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (Session::*_t)(BitTorrent::TorrentHandle * const );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::torrentNew)) {
                *result = 3;
                return;
            }
        }
        {
            typedef void (Session::*_t)(BitTorrent::TorrentHandle * const );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::torrentAboutToBeRemoved)) {
                *result = 4;
                return;
            }
        }
        {
            typedef void (Session::*_t)(BitTorrent::TorrentHandle * const );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::torrentPaused)) {
                *result = 5;
                return;
            }
        }
        {
            typedef void (Session::*_t)(BitTorrent::TorrentHandle * const );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::torrentResumed)) {
                *result = 6;
                return;
            }
        }
        {
            typedef void (Session::*_t)(BitTorrent::TorrentHandle * const );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::torrentFinished)) {
                *result = 7;
                return;
            }
        }
        {
            typedef void (Session::*_t)(BitTorrent::TorrentHandle * const );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::torrentFinishedChecking)) {
                *result = 8;
                return;
            }
        }
        {
            typedef void (Session::*_t)(BitTorrent::TorrentHandle * const );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::torrentSavePathChanged)) {
                *result = 9;
                return;
            }
        }
        {
            typedef void (Session::*_t)(BitTorrent::TorrentHandle * const , const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::torrentCategoryChanged)) {
                *result = 10;
                return;
            }
        }
        {
            typedef void (Session::*_t)(BitTorrent::TorrentHandle * const );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::torrentSavingModeChanged)) {
                *result = 11;
                return;
            }
        }
        {
            typedef void (Session::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::allTorrentsFinished)) {
                *result = 12;
                return;
            }
        }
        {
            typedef void (Session::*_t)(const BitTorrent::TorrentInfo & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::metadataLoaded)) {
                *result = 13;
                return;
            }
        }
        {
            typedef void (Session::*_t)(BitTorrent::TorrentHandle * const );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::torrentMetadataLoaded)) {
                *result = 14;
                return;
            }
        }
        {
            typedef void (Session::*_t)(BitTorrent::TorrentHandle * const , const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::fullDiskError)) {
                *result = 15;
                return;
            }
        }
        {
            typedef void (Session::*_t)(BitTorrent::TorrentHandle * const , const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::trackerSuccess)) {
                *result = 16;
                return;
            }
        }
        {
            typedef void (Session::*_t)(BitTorrent::TorrentHandle * const , const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::trackerWarning)) {
                *result = 17;
                return;
            }
        }
        {
            typedef void (Session::*_t)(BitTorrent::TorrentHandle * const , const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::trackerError)) {
                *result = 18;
                return;
            }
        }
        {
            typedef void (Session::*_t)(BitTorrent::TorrentHandle * const );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::trackerAuthenticationRequired)) {
                *result = 19;
                return;
            }
        }
        {
            typedef void (Session::*_t)(BitTorrent::TorrentHandle * const );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::recursiveTorrentDownloadPossible)) {
                *result = 20;
                return;
            }
        }
        {
            typedef void (Session::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::speedLimitModeChanged)) {
                *result = 21;
                return;
            }
        }
        {
            typedef void (Session::*_t)(bool , int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::IPFilterParsed)) {
                *result = 22;
                return;
            }
        }
        {
            typedef void (Session::*_t)(BitTorrent::TorrentHandle * const , const QList<BitTorrent::TrackerEntry> & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::trackersAdded)) {
                *result = 23;
                return;
            }
        }
        {
            typedef void (Session::*_t)(BitTorrent::TorrentHandle * const , const QList<BitTorrent::TrackerEntry> & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::trackersRemoved)) {
                *result = 24;
                return;
            }
        }
        {
            typedef void (Session::*_t)(BitTorrent::TorrentHandle * const );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::trackersChanged)) {
                *result = 25;
                return;
            }
        }
        {
            typedef void (Session::*_t)(BitTorrent::TorrentHandle * const , bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::trackerlessStateChanged)) {
                *result = 26;
                return;
            }
        }
        {
            typedef void (Session::*_t)(const QString & , const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::downloadFromUrlFailed)) {
                *result = 27;
                return;
            }
        }
        {
            typedef void (Session::*_t)(const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::downloadFromUrlFinished)) {
                *result = 28;
                return;
            }
        }
        {
            typedef void (Session::*_t)(const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::categoryAdded)) {
                *result = 29;
                return;
            }
        }
        {
            typedef void (Session::*_t)(const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::categoryRemoved)) {
                *result = 30;
                return;
            }
        }
        {
            typedef void (Session::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Session::subcategoriesSupportChanged)) {
                *result = 31;
                return;
            }
        }
    }
}

const QMetaObject BitTorrent::Session::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_BitTorrent__Session.data,
      qt_meta_data_BitTorrent__Session,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *BitTorrent::Session::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *BitTorrent::Session::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_BitTorrent__Session.stringdata0))
        return static_cast<void*>(const_cast< Session*>(this));
    return QObject::qt_metacast(_clname);
}

int BitTorrent::Session::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 47)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 47;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 47)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 47;
    }
    return _id;
}

// SIGNAL 0
void BitTorrent::Session::torrentsUpdated()
{
    QMetaObject::activate(this, &staticMetaObject, 0, Q_NULLPTR);
}

// SIGNAL 1
void BitTorrent::Session::addTorrentFailed(const QString & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void BitTorrent::Session::torrentAdded(BitTorrent::TorrentHandle * const _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void BitTorrent::Session::torrentNew(BitTorrent::TorrentHandle * const _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void BitTorrent::Session::torrentAboutToBeRemoved(BitTorrent::TorrentHandle * const _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void BitTorrent::Session::torrentPaused(BitTorrent::TorrentHandle * const _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void BitTorrent::Session::torrentResumed(BitTorrent::TorrentHandle * const _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void BitTorrent::Session::torrentFinished(BitTorrent::TorrentHandle * const _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void BitTorrent::Session::torrentFinishedChecking(BitTorrent::TorrentHandle * const _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void BitTorrent::Session::torrentSavePathChanged(BitTorrent::TorrentHandle * const _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void BitTorrent::Session::torrentCategoryChanged(BitTorrent::TorrentHandle * const _t1, const QString & _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void BitTorrent::Session::torrentSavingModeChanged(BitTorrent::TorrentHandle * const _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void BitTorrent::Session::allTorrentsFinished()
{
    QMetaObject::activate(this, &staticMetaObject, 12, Q_NULLPTR);
}

// SIGNAL 13
void BitTorrent::Session::metadataLoaded(const BitTorrent::TorrentInfo & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 13, _a);
}

// SIGNAL 14
void BitTorrent::Session::torrentMetadataLoaded(BitTorrent::TorrentHandle * const _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 14, _a);
}

// SIGNAL 15
void BitTorrent::Session::fullDiskError(BitTorrent::TorrentHandle * const _t1, const QString & _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 15, _a);
}

// SIGNAL 16
void BitTorrent::Session::trackerSuccess(BitTorrent::TorrentHandle * const _t1, const QString & _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 16, _a);
}

// SIGNAL 17
void BitTorrent::Session::trackerWarning(BitTorrent::TorrentHandle * const _t1, const QString & _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 17, _a);
}

// SIGNAL 18
void BitTorrent::Session::trackerError(BitTorrent::TorrentHandle * const _t1, const QString & _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 18, _a);
}

// SIGNAL 19
void BitTorrent::Session::trackerAuthenticationRequired(BitTorrent::TorrentHandle * const _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 19, _a);
}

// SIGNAL 20
void BitTorrent::Session::recursiveTorrentDownloadPossible(BitTorrent::TorrentHandle * const _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 20, _a);
}

// SIGNAL 21
void BitTorrent::Session::speedLimitModeChanged(bool _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 21, _a);
}

// SIGNAL 22
void BitTorrent::Session::IPFilterParsed(bool _t1, int _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 22, _a);
}

// SIGNAL 23
void BitTorrent::Session::trackersAdded(BitTorrent::TorrentHandle * const _t1, const QList<BitTorrent::TrackerEntry> & _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 23, _a);
}

// SIGNAL 24
void BitTorrent::Session::trackersRemoved(BitTorrent::TorrentHandle * const _t1, const QList<BitTorrent::TrackerEntry> & _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 24, _a);
}

// SIGNAL 25
void BitTorrent::Session::trackersChanged(BitTorrent::TorrentHandle * const _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 25, _a);
}

// SIGNAL 26
void BitTorrent::Session::trackerlessStateChanged(BitTorrent::TorrentHandle * const _t1, bool _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 26, _a);
}

// SIGNAL 27
void BitTorrent::Session::downloadFromUrlFailed(const QString & _t1, const QString & _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 27, _a);
}

// SIGNAL 28
void BitTorrent::Session::downloadFromUrlFinished(const QString & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 28, _a);
}

// SIGNAL 29
void BitTorrent::Session::categoryAdded(const QString & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 29, _a);
}

// SIGNAL 30
void BitTorrent::Session::categoryRemoved(const QString & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 30, _a);
}

// SIGNAL 31
void BitTorrent::Session::subcategoriesSupportChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 31, Q_NULLPTR);
}
QT_END_MOC_NAMESPACE
