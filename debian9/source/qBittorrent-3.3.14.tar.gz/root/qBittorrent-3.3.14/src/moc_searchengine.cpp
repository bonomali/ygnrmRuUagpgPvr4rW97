/****************************************************************************
** Meta object code from reading C++ file 'searchengine.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "base/searchengine.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'searchengine.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_SearchEngine_t {
    QByteArrayData data[33];
    char stringdata0[486];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SearchEngine_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SearchEngine_t qt_meta_stringdata_SearchEngine = {
    {
QT_MOC_LITERAL(0, 0, 12), // "SearchEngine"
QT_MOC_LITERAL(1, 13, 13), // "searchStarted"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 14), // "searchFinished"
QT_MOC_LITERAL(4, 43, 9), // "cancelled"
QT_MOC_LITERAL(5, 53, 12), // "searchFailed"
QT_MOC_LITERAL(6, 66, 16), // "newSearchResults"
QT_MOC_LITERAL(7, 83, 19), // "QList<SearchResult>"
QT_MOC_LITERAL(8, 103, 7), // "results"
QT_MOC_LITERAL(9, 111, 15), // "pluginInstalled"
QT_MOC_LITERAL(10, 127, 4), // "name"
QT_MOC_LITERAL(11, 132, 24), // "pluginInstallationFailed"
QT_MOC_LITERAL(12, 157, 6), // "reason"
QT_MOC_LITERAL(13, 164, 13), // "pluginUpdated"
QT_MOC_LITERAL(14, 178, 18), // "pluginUpdateFailed"
QT_MOC_LITERAL(15, 197, 23), // "checkForUpdatesFinished"
QT_MOC_LITERAL(16, 221, 20), // "QHash<QString,qreal>"
QT_MOC_LITERAL(17, 242, 10), // "updateInfo"
QT_MOC_LITERAL(18, 253, 21), // "checkForUpdatesFailed"
QT_MOC_LITERAL(19, 275, 21), // "torrentFileDownloaded"
QT_MOC_LITERAL(20, 297, 4), // "path"
QT_MOC_LITERAL(21, 302, 9), // "onTimeout"
QT_MOC_LITERAL(22, 312, 16), // "readSearchOutput"
QT_MOC_LITERAL(23, 329, 15), // "processFinished"
QT_MOC_LITERAL(24, 345, 8), // "exitcode"
QT_MOC_LITERAL(25, 354, 21), // "versionInfoDownloaded"
QT_MOC_LITERAL(26, 376, 3), // "url"
QT_MOC_LITERAL(27, 380, 4), // "data"
QT_MOC_LITERAL(28, 385, 25), // "versionInfoDownloadFailed"
QT_MOC_LITERAL(29, 411, 16), // "pluginDownloaded"
QT_MOC_LITERAL(30, 428, 8), // "filePath"
QT_MOC_LITERAL(31, 437, 20), // "pluginDownloadFailed"
QT_MOC_LITERAL(32, 458, 27) // "torrentFileDownloadFinished"

    },
    "SearchEngine\0searchStarted\0\0searchFinished\0"
    "cancelled\0searchFailed\0newSearchResults\0"
    "QList<SearchResult>\0results\0pluginInstalled\0"
    "name\0pluginInstallationFailed\0reason\0"
    "pluginUpdated\0pluginUpdateFailed\0"
    "checkForUpdatesFinished\0QHash<QString,qreal>\0"
    "updateInfo\0checkForUpdatesFailed\0"
    "torrentFileDownloaded\0path\0onTimeout\0"
    "readSearchOutput\0processFinished\0"
    "exitcode\0versionInfoDownloaded\0url\0"
    "data\0versionInfoDownloadFailed\0"
    "pluginDownloaded\0filePath\0"
    "pluginDownloadFailed\0torrentFileDownloadFinished"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SearchEngine[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      19,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      11,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  109,    2, 0x06 /* Public */,
       3,    1,  110,    2, 0x06 /* Public */,
       5,    0,  113,    2, 0x06 /* Public */,
       6,    1,  114,    2, 0x06 /* Public */,
       9,    1,  117,    2, 0x06 /* Public */,
      11,    2,  120,    2, 0x06 /* Public */,
      13,    1,  125,    2, 0x06 /* Public */,
      14,    2,  128,    2, 0x06 /* Public */,
      15,    1,  133,    2, 0x06 /* Public */,
      18,    1,  136,    2, 0x06 /* Public */,
      19,    1,  139,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      21,    0,  142,    2, 0x08 /* Private */,
      22,    0,  143,    2, 0x08 /* Private */,
      23,    1,  144,    2, 0x08 /* Private */,
      25,    2,  147,    2, 0x08 /* Private */,
      28,    2,  152,    2, 0x08 /* Private */,
      29,    2,  157,    2, 0x08 /* Private */,
      31,    2,  162,    2, 0x08 /* Private */,
      32,    1,  167,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    4,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 7,    8,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   10,   12,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   10,   12,
    QMetaType::Void, 0x80000000 | 16,   17,
    QMetaType::Void, QMetaType::QString,   12,
    QMetaType::Void, QMetaType::QString,   20,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   24,
    QMetaType::Void, QMetaType::QString, QMetaType::QByteArray,   26,   27,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   26,   12,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   26,   30,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   26,   12,
    QMetaType::Void, QMetaType::Int,   24,

       0        // eod
};

void SearchEngine::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        SearchEngine *_t = static_cast<SearchEngine *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->searchStarted(); break;
        case 1: _t->searchFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->searchFailed(); break;
        case 3: _t->newSearchResults((*reinterpret_cast< const QList<SearchResult>(*)>(_a[1]))); break;
        case 4: _t->pluginInstalled((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 5: _t->pluginInstallationFailed((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 6: _t->pluginUpdated((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 7: _t->pluginUpdateFailed((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 8: _t->checkForUpdatesFinished((*reinterpret_cast< const QHash<QString,qreal>(*)>(_a[1]))); break;
        case 9: _t->checkForUpdatesFailed((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 10: _t->torrentFileDownloaded((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 11: _t->onTimeout(); break;
        case 12: _t->readSearchOutput(); break;
        case 13: _t->processFinished((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->versionInfoDownloaded((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QByteArray(*)>(_a[2]))); break;
        case 15: _t->versionInfoDownloadFailed((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 16: _t->pluginDownloaded((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 17: _t->pluginDownloadFailed((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 18: _t->torrentFileDownloadFinished((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (SearchEngine::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SearchEngine::searchStarted)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (SearchEngine::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SearchEngine::searchFinished)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (SearchEngine::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SearchEngine::searchFailed)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (SearchEngine::*_t)(const QList<SearchResult> & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SearchEngine::newSearchResults)) {
                *result = 3;
                return;
            }
        }
        {
            typedef void (SearchEngine::*_t)(const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SearchEngine::pluginInstalled)) {
                *result = 4;
                return;
            }
        }
        {
            typedef void (SearchEngine::*_t)(const QString & , const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SearchEngine::pluginInstallationFailed)) {
                *result = 5;
                return;
            }
        }
        {
            typedef void (SearchEngine::*_t)(const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SearchEngine::pluginUpdated)) {
                *result = 6;
                return;
            }
        }
        {
            typedef void (SearchEngine::*_t)(const QString & , const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SearchEngine::pluginUpdateFailed)) {
                *result = 7;
                return;
            }
        }
        {
            typedef void (SearchEngine::*_t)(const QHash<QString,qreal> & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SearchEngine::checkForUpdatesFinished)) {
                *result = 8;
                return;
            }
        }
        {
            typedef void (SearchEngine::*_t)(const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SearchEngine::checkForUpdatesFailed)) {
                *result = 9;
                return;
            }
        }
        {
            typedef void (SearchEngine::*_t)(const QString & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SearchEngine::torrentFileDownloaded)) {
                *result = 10;
                return;
            }
        }
    }
}

const QMetaObject SearchEngine::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_SearchEngine.data,
      qt_meta_data_SearchEngine,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *SearchEngine::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SearchEngine::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_SearchEngine.stringdata0))
        return static_cast<void*>(const_cast< SearchEngine*>(this));
    return QObject::qt_metacast(_clname);
}

int SearchEngine::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 19)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 19)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 19;
    }
    return _id;
}

// SIGNAL 0
void SearchEngine::searchStarted()
{
    QMetaObject::activate(this, &staticMetaObject, 0, Q_NULLPTR);
}

// SIGNAL 1
void SearchEngine::searchFinished(bool _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void SearchEngine::searchFailed()
{
    QMetaObject::activate(this, &staticMetaObject, 2, Q_NULLPTR);
}

// SIGNAL 3
void SearchEngine::newSearchResults(const QList<SearchResult> & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void SearchEngine::pluginInstalled(const QString & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void SearchEngine::pluginInstallationFailed(const QString & _t1, const QString & _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void SearchEngine::pluginUpdated(const QString & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void SearchEngine::pluginUpdateFailed(const QString & _t1, const QString & _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void SearchEngine::checkForUpdatesFinished(const QHash<QString,qreal> & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void SearchEngine::checkForUpdatesFailed(const QString & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void SearchEngine::torrentFileDownloaded(const QString & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}
QT_END_MOC_NAMESPACE
